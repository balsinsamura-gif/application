require('dotenv').config();

const required = ['DATABASE_URL', 'JWT_SECRET'];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
}

module.exports = {
  port: Number(process.env.PORT || 4000),
  databaseUrl: process.env.DATABASE_URL,
  jwtSecret: process.env.JWT_SECRET,
  appName: process.env.APP_NAME || 'Way Out',
  pricing: {
    baseFee: Number(process.env.BASE_FEE || 10),
    perKm: Number(process.env.PRICE_PER_KM || 5),
    minFee: Number(process.env.MIN_FEE || 15),
  },
  referralRewardPercent: Number(process.env.REFERRAL_REWARD_PERCENT || 5),
  smsProvider: process.env.SMS_PROVIDER || 'console',
  emailProvider: process.env.EMAIL_PROVIDER || 'console',
  paymentProvider: process.env.PAYMENT_PROVIDER || 'mock',
};
