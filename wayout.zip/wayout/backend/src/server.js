const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const config = require('./config');

const app = express();
app.use(cors());
app.use(express.json());

// Slow down brute-force attempts on login, verification and registration
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 50,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Try again in a few minutes.' },
});

app.get('/health', (req, res) => res.json({ ok: true }));

app.use('/auth', authLimiter, require('./routes/auth'));
app.use('/', require('./routes/profiles'));
app.use('/', require('./routes/professions'));
app.use('/deliveries', require('./routes/deliveries'));
app.use('/services', require('./routes/services'));
// Chat polls every few seconds, so allow plenty of reads but still stop message spam
const chatLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Slow down a little.' },
});
app.use('/messages', chatLimiter, require('./routes/messages'));
app.use('/business', require('./routes/business'));

app.use((req, res) => res.status(404).json({ error: 'Not found' }));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong' });
});

app.listen(config.port, () => {
  console.log(`${config.appName} API listening on port ${config.port}`);
});
