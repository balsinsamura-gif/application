-- Requires PostgreSQL 13 or newer (gen_random_uuid is built in).

-- Accounts: one row per login. account_type decides the dashboard and rules.
CREATE TABLE IF NOT EXISTS users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_type    TEXT NOT NULL CHECK (account_type IN ('individual', 'business')),
  email           TEXT NOT NULL UNIQUE,
  phone           TEXT NOT NULL UNIQUE,
  password_hash   TEXT NOT NULL,
  email_verified  BOOLEAN NOT NULL DEFAULT FALSE,
  phone_verified  BOOLEAN NOT NULL DEFAULT FALSE,
  totp_secret     TEXT,
  totp_enabled    BOOLEAN NOT NULL DEFAULT FALSE,
  biometric_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  call_enabled    BOOLEAN NOT NULL DEFAULT TRUE,
  share_slug      TEXT NOT NULL UNIQUE,
  referral_code   TEXT UNIQUE,            -- only set for business accounts
  referred_by     UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS individual_profiles (
  user_id     UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  full_name   TEXT NOT NULL,
  address     TEXT,
  city        TEXT,
  bio         TEXT
);

CREATE TABLE IF NOT EXISTS business_profiles (
  user_id          UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  company_name     TEXT NOT NULL,
  registration_no  TEXT,
  contact_person   TEXT,
  address          TEXT,
  city             TEXT,
  description      TEXT
);

-- Profile categories ("different categories of profile specifications")
CREATE TABLE IF NOT EXISTS categories (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL UNIQUE,
  applies_to  TEXT NOT NULL CHECK (applies_to IN ('individual', 'business', 'both'))
);

CREATE TABLE IF NOT EXISTS profile_categories (
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id  INT  NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, category_id)
);

-- One-time codes for email and phone verification
CREATE TABLE IF NOT EXISTS verification_codes (
  id          SERIAL PRIMARY KEY,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel     TEXT NOT NULL CHECK (channel IN ('email', 'phone', 'login')),
  code_hash   TEXT NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  attempts    INT NOT NULL DEFAULT 0,
  used        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Device tokens for fingerprint login. The phone keeps the token behind its biometric lock;
-- only a hash is stored here.
CREATE TABLE IF NOT EXISTS device_tokens (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  device_name TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_used_at TIMESTAMPTZ
);

-- Transport slots that businesses buy
CREATE TABLE IF NOT EXISTS transport_types (
  id     SERIAL PRIMARY KEY,
  name   TEXT NOT NULL UNIQUE,
  slot_price NUMERIC(12,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS slots (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  transport_type_id INT NOT NULL REFERENCES transport_types(id),
  quantity      INT NOT NULL CHECK (quantity > 0),
  total_paid    NUMERIC(12,2) NOT NULL,
  payment_id    UUID,
  starts_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at    TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS deliveries (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id  UUID NOT NULL REFERENCES users(id),
  provider_id   UUID REFERENCES users(id),
  pickup_address   TEXT NOT NULL,
  dropoff_address  TEXT NOT NULL,
  pickup_lat    DOUBLE PRECISION NOT NULL,
  pickup_lng    DOUBLE PRECISION NOT NULL,
  dropoff_lat   DOUBLE PRECISION NOT NULL,
  dropoff_lng   DOUBLE PRECISION NOT NULL,
  distance_km   NUMERIC(8,2) NOT NULL,
  price         NUMERIC(12,2) NOT NULL,
  transport_type_id INT REFERENCES transport_types(id),
  item_description TEXT,
  recipient_name   TEXT,
  recipient_phone  TEXT,
  -- "personal received and delivery": the requester collects (pickup_self) and/or receives (receive_self)
  mode          TEXT NOT NULL DEFAULT 'send' CHECK (mode IN ('send', 'receive')),
  status        TEXT NOT NULL DEFAULT 'requested'
                CHECK (status IN ('requested', 'accepted', 'picked_up', 'delivered', 'cancelled')),
  paid          BOOLEAN NOT NULL DEFAULT FALSE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Latest known courier position for a delivery (used for live map tracking)
CREATE TABLE IF NOT EXISTS delivery_locations (
  delivery_id  UUID PRIMARY KEY REFERENCES deliveries(id) ON DELETE CASCADE,
  lat          DOUBLE PRECISION NOT NULL,
  lng          DOUBLE PRECISION NOT NULL,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Professions a person or company can offer (chosen at sign-up, editable later)
CREATE TABLE IF NOT EXISTS professions (
  id         SERIAL PRIMARY KEY,
  name       TEXT NOT NULL UNIQUE,
  uses_rate  BOOLEAN NOT NULL DEFAULT TRUE   -- FALSE for delivery, which is priced by distance
);

CREATE TABLE IF NOT EXISTS user_professions (
  user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  profession_id  INT  NOT NULL REFERENCES professions(id) ON DELETE CASCADE,
  rate           NUMERIC(12,2) CHECK (rate IS NULL OR rate >= 0),
  rate_unit      TEXT NOT NULL DEFAULT 'per_hour' CHECK (rate_unit IN ('per_hour', 'per_visit')),
  summary        TEXT,
  PRIMARY KEY (user_id, profession_id)
);

-- A customer asks one specific professional for a service (not a delivery)
CREATE TABLE IF NOT EXISTS service_requests (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id    UUID NOT NULL REFERENCES users(id),
  provider_id    UUID NOT NULL REFERENCES users(id),
  profession_id  INT  NOT NULL REFERENCES professions(id),
  description    TEXT NOT NULL,
  address        TEXT NOT NULL,
  scheduled_at   TIMESTAMPTZ NOT NULL,
  hours          NUMERIC(5,2) NOT NULL DEFAULT 1 CHECK (hours > 0),
  price          NUMERIC(12,2) NOT NULL,
  status         TEXT NOT NULL DEFAULT 'requested'
                 CHECK (status IN ('requested', 'accepted', 'declined', 'completed', 'cancelled')),
  paid           BOOLEAN NOT NULL DEFAULT FALSE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (customer_id <> provider_id)
);

-- Direct messages between two accounts
CREATE TABLE IF NOT EXISTS messages (
  id            BIGSERIAL PRIMARY KEY,
  sender_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body          TEXT NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  read_at       TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (sender_id <> recipient_id)
);

CREATE TABLE IF NOT EXISTS payments (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID NOT NULL REFERENCES users(id),
  purpose       TEXT NOT NULL CHECK (purpose IN ('delivery', 'slot', 'service')),
  reference_id  UUID,
  amount        NUMERIC(12,2) NOT NULL,
  msisdn        TEXT NOT NULL,
  provider      TEXT NOT NULL,
  provider_ref  TEXT,
  status        TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'succeeded', 'failed')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ratings (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_id   UUID UNIQUE REFERENCES deliveries(id) ON DELETE CASCADE,
  service_id    UUID UNIQUE REFERENCES service_requests(id) ON DELETE CASCADE,
  rater_id      UUID NOT NULL REFERENCES users(id),
  rated_id      UUID NOT NULL REFERENCES users(id),
  stars         INT NOT NULL CHECK (stars BETWEEN 1 AND 5),
  comment       TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- a rating belongs to exactly one delivery or one service
  CHECK ((delivery_id IS NOT NULL)::int + (service_id IS NOT NULL)::int = 1)
);

CREATE TABLE IF NOT EXISTS referral_rewards (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id   UUID NOT NULL REFERENCES users(id),
  referred_id   UUID NOT NULL REFERENCES users(id),
  slot_id       UUID REFERENCES slots(id),
  amount        NUMERIC(12,2) NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (referred_id)   -- reward only on the referred business's first slot purchase
);

CREATE INDEX IF NOT EXISTS idx_deliveries_requester ON deliveries(requester_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_provider ON deliveries(provider_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_status ON deliveries(status);
CREATE INDEX IF NOT EXISTS idx_ratings_rated ON ratings(rated_id);
CREATE INDEX IF NOT EXISTS idx_service_customer ON service_requests(customer_id);
CREATE INDEX IF NOT EXISTS idx_service_provider ON service_requests(provider_id);
CREATE INDEX IF NOT EXISTS idx_messages_pair ON messages(sender_id, recipient_id, id);
CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_id, read_at);
CREATE INDEX IF NOT EXISTS idx_user_professions_prof ON user_professions(profession_id);

INSERT INTO categories (name, applies_to) VALUES
  ('Retail shop', 'business'),
  ('Restaurant / food', 'business'),
  ('Logistics company', 'business'),
  ('NGO / organization', 'business'),
  ('Pharmacy / health', 'business'),
  ('Home and family services agency', 'business'),
  ('Education / tutoring centre', 'business'),
  ('General', 'both')
ON CONFLICT (name) DO NOTHING;

INSERT INTO professions (name, uses_rate) VALUES
  ('Delivery service', FALSE),
  ('Personal caregiver', TRUE),
  ('Personal chef', TRUE),
  ('Private tutor', TRUE),
  ('Housekeeper', TRUE)
ON CONFLICT (name) DO NOTHING;

INSERT INTO transport_types (name, slot_price) VALUES
  ('Motorbike', 50),
  ('Car', 120),
  ('Van', 200),
  ('Truck', 400),
  ('Bicycle', 20)
ON CONFLICT (name) DO NOTHING;
