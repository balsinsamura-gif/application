const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const { professionList, setProfessions } = require('../services/professions');

const router = express.Router();

router.get('/meta/professions', async (req, res) => {
  const { rows } = await db.query('SELECT id, name, uses_rate AS "usesRate" FROM professions ORDER BY id');
  res.json(rows);
});

// Find professionals. Only fully verified accounts are listed.
router.get('/providers', async (req, res) => {
  try {
    const q = z
      .object({
        professionId: z.coerce.number().int().optional(),
        city: z.string().max(100).optional(),
        search: z.string().max(100).optional(),
      })
      .parse(req.query);

    const { rows } = await db.query(
      `SELECT u.id AS "userId", u.share_slug AS "shareSlug", u.account_type AS "accountType",
              COALESCE(bp.company_name, ip.full_name) AS name,
              COALESCE(bp.city, ip.city) AS city,
              p.id AS "professionId", p.name AS "professionName",
              up.rate, up.rate_unit AS "rateUnit", up.summary,
              COALESCE((SELECT ROUND(AVG(stars)::numeric, 2) FROM ratings r WHERE r.rated_id = u.id), 0) AS "ratingAverage",
              (SELECT COUNT(*)::int FROM ratings r WHERE r.rated_id = u.id) AS "ratingCount"
       FROM user_professions up
       JOIN users u ON u.id = up.user_id AND u.email_verified AND u.phone_verified
       JOIN professions p ON p.id = up.profession_id
       LEFT JOIN individual_profiles ip ON ip.user_id = u.id
       LEFT JOIN business_profiles bp ON bp.user_id = u.id
       WHERE ($1::int IS NULL OR p.id = $1)
         AND ($2::text IS NULL OR COALESCE(bp.city, ip.city) ILIKE '%' || $2 || '%')
         AND ($3::text IS NULL OR COALESCE(bp.company_name, ip.full_name) ILIKE '%' || $3 || '%')
       ORDER BY "ratingAverage" DESC, "ratingCount" DESC
       LIMIT 50`,
      [q.professionId ?? null, q.city || null, q.search || null]
    );
    res.json(
      rows.map((r) => ({
        ...r,
        rate: r.rate === null ? null : Number(r.rate),
        ratingAverage: Number(r.ratingAverage),
      }))
    );
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: err.issues.map((i) => i.message).join('; ') });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

// Change which professions I offer and my rates
router.put('/me/professions', requireAuth, async (req, res) => {
  try {
    const items = professionList.parse(req.body.professions);
    await db.tx((client) => setProfessions(client, req.user.id, items));
    res.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: err.issues.map((i) => i.message).join('; ') });
    if (err.status === 400) return res.status(400).json({ error: err.message });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

module.exports = router;
