const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { z } = require('zod');
const { authenticator } = require('otplib');
const QRCode = require('qrcode');

const db = require('../db');
const config = require('../config');
const { issueCode, checkCode } = require('../services/codes');
const { professionList, setProfessions } = require('../services/professions');
const {
  signAccessToken,
  signChallengeToken,
  verifyChallengeToken,
  requireAuth,
} = require('../middleware/auth');

const router = express.Router();

const baseRegister = {
  email: z.string().email().toLowerCase(),
  phone: z.string().regex(/^\+?[0-9]{8,15}$/, 'Phone must be digits, optionally starting with +'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  address: z.string().optional(),
  city: z.string().optional(),
  categoryIds: z.array(z.number().int()).optional(),
  // Professions offered (delivery service, caregiver, chef, tutor, housekeeper...). Optional.
  professions: professionList.optional(),
};

const individualSchema = z.object({
  ...baseRegister,
  fullName: z.string().min(2),
  bio: z.string().optional(),
  // Referral links are for businesses and organizations only
  referralCode: z.undefined({ message: 'Referral codes are only for business accounts' }),
});

const businessSchema = z.object({
  ...baseRegister,
  companyName: z.string().min(2),
  registrationNo: z.string().optional(),
  contactPerson: z.string().optional(),
  description: z.string().optional(),
  referralCode: z.string().optional(),
});

const newSlug = () => crypto.randomBytes(5).toString('hex');
const newReferralCode = () => 'B' + crypto.randomBytes(4).toString('hex').toUpperCase();

function fail(res, err) {
  if (err instanceof z.ZodError) {
    return res.status(400).json({ error: err.issues.map((i) => i.message).join('; ') });
  }
  console.error(err);
  return res.status(500).json({ error: 'Something went wrong' });
}

async function register(req, res, accountType, schema) {
  try {
    const data = schema.parse(req.body);
    const passwordHash = await bcrypt.hash(data.password, 12);

    let referrerId = null;
    if (accountType === 'business' && data.referralCode) {
      const { rows } = await db.query(
        `SELECT id FROM users WHERE referral_code = $1 AND account_type = 'business'`,
        [data.referralCode.toUpperCase()]
      );
      if (!rows[0]) return res.status(400).json({ error: 'Referral code not found' });
      referrerId = rows[0].id;
    }

    const user = await db.tx(async (client) => {
      const inserted = await client.query(
        `INSERT INTO users (account_type, email, phone, password_hash, share_slug, referral_code, referred_by)
         VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
        [
          accountType,
          data.email,
          data.phone,
          passwordHash,
          newSlug(),
          accountType === 'business' ? newReferralCode() : null,
          referrerId,
        ]
      );
      const u = inserted.rows[0];

      if (accountType === 'individual') {
        await client.query(
          `INSERT INTO individual_profiles (user_id, full_name, address, city, bio) VALUES ($1,$2,$3,$4,$5)`,
          [u.id, data.fullName, data.address || null, data.city || null, data.bio || null]
        );
      } else {
        await client.query(
          `INSERT INTO business_profiles (user_id, company_name, registration_no, contact_person, address, city, description)
           VALUES ($1,$2,$3,$4,$5,$6,$7)`,
          [
            u.id,
            data.companyName,
            data.registrationNo || null,
            data.contactPerson || null,
            data.address || null,
            data.city || null,
            data.description || null,
          ]
        );
      }

      // Only keep categories that fit this account type
      if (data.categoryIds && data.categoryIds.length) {
        await client.query(
          `INSERT INTO profile_categories (user_id, category_id)
           SELECT $1, id FROM categories
           WHERE id = ANY($2::int[]) AND applies_to IN ($3, 'both')`,
          [u.id, data.categoryIds, accountType]
        );
      }
      if (data.professions && data.professions.length) {
        await setProfessions(client, u.id, data.professions);
      }
      return u;
    });

    await issueCode(user, 'email');
    await issueCode(user, 'phone');

    res.status(201).json({
      status: 'verification_required',
      challengeToken: signChallengeToken(user),
      message: 'We sent a code to your email and a code to your phone.',
    });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ error: 'That email or phone number is already registered' });
    }
    if (err.status === 400) return res.status(400).json({ error: err.message });
    fail(res, err);
  }
}

router.post('/register/individual', (req, res) => register(req, res, 'individual', individualSchema));
router.post('/register/business', (req, res) => register(req, res, 'business', businessSchema));

async function userFromChallenge(token) {
  const payload = verifyChallengeToken(token);
  const { rows } = await db.query('SELECT * FROM users WHERE id = $1', [payload.sub]);
  return rows[0];
}

const verifySchema = z.object({
  challengeToken: z.string(),
  channel: z.enum(['email', 'phone']),
  code: z.string().length(6),
});

// Email and phone code verification
router.post('/verify', async (req, res) => {
  try {
    const { challengeToken, channel, code } = verifySchema.parse(req.body);
    const user = await userFromChallenge(challengeToken);
    if (!user) return res.status(401).json({ error: 'Invalid session' });

    const ok = await checkCode(user.id, channel, code);
    if (!ok) return res.status(400).json({ error: 'Wrong or expired code' });

    const column = channel === 'email' ? 'email_verified' : 'phone_verified';
    const { rows } = await db.query(`UPDATE users SET ${column} = TRUE WHERE id = $1 RETURNING *`, [user.id]);
    const updated = rows[0];

    const complete = updated.email_verified && updated.phone_verified;
    res.json({
      status: complete ? 'verified' : 'verification_required',
      emailVerified: updated.email_verified,
      phoneVerified: updated.phone_verified,
      ...(complete ? { accessToken: signAccessToken(updated) } : {}),
    });
  } catch (err) {
    if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }
    fail(res, err);
  }
});

router.post('/resend', async (req, res) => {
  try {
    const { challengeToken, channel } = z
      .object({ challengeToken: z.string(), channel: z.enum(['email', 'phone']) })
      .parse(req.body);
    const user = await userFromChallenge(challengeToken);
    if (!user) return res.status(401).json({ error: 'Invalid session' });
    await issueCode(user, channel);
    res.json({ ok: true });
  } catch (err) {
    fail(res, err);
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = z
      .object({ email: z.string().email().toLowerCase(), password: z.string() })
      .parse(req.body);

    const { rows } = await db.query('SELECT * FROM users WHERE email = $1', [email]);
    const user = rows[0];
    const ok = user && (await bcrypt.compare(password, user.password_hash));
    if (!ok) return res.status(401).json({ error: 'Wrong email or password' });

    if (!user.email_verified || !user.phone_verified) {
      if (!user.email_verified) await issueCode(user, 'email');
      if (!user.phone_verified) await issueCode(user, 'phone');
      return res.json({
        status: 'verification_required',
        emailVerified: user.email_verified,
        phoneVerified: user.phone_verified,
        challengeToken: signChallengeToken(user),
      });
    }

    if (user.totp_enabled) {
      return res.json({ status: '2fa_required', challengeToken: signChallengeToken(user) });
    }

    res.json({ status: 'ok', accessToken: signAccessToken(user) });
  } catch (err) {
    fail(res, err);
  }
});

// Second step of login for accounts with two-factor authentication on
router.post('/login/2fa', async (req, res) => {
  try {
    const { challengeToken, code } = z
      .object({ challengeToken: z.string(), code: z.string().length(6) })
      .parse(req.body);
    const user = await userFromChallenge(challengeToken);
    if (!user || !user.totp_enabled) return res.status(401).json({ error: 'Invalid session' });

    if (!authenticator.check(code, user.totp_secret)) {
      return res.status(400).json({ error: 'Wrong code' });
    }
    res.json({ status: 'ok', accessToken: signAccessToken(user) });
  } catch (err) {
    if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }
    fail(res, err);
  }
});

// ---- Two-factor authentication (authenticator app) ----
router.post('/2fa/setup', requireAuth, async (req, res) => {
  try {
    if (req.user.totp_enabled) return res.status(400).json({ error: '2FA is already on' });
    const secret = authenticator.generateSecret();
    await db.query('UPDATE users SET totp_secret = $1 WHERE id = $2', [secret, req.user.id]);
    const otpauth = authenticator.keyuri(req.user.email, config.appName, secret);
    res.json({ secret, otpauthUrl: otpauth, qrDataUrl: await QRCode.toDataURL(otpauth) });
  } catch (err) {
    fail(res, err);
  }
});

router.post('/2fa/enable', requireAuth, async (req, res) => {
  try {
    const { code } = z.object({ code: z.string().length(6) }).parse(req.body);
    if (!req.user.totp_secret) return res.status(400).json({ error: 'Start 2FA setup first' });
    if (!authenticator.check(code, req.user.totp_secret)) {
      return res.status(400).json({ error: 'Wrong code' });
    }
    await db.query('UPDATE users SET totp_enabled = TRUE WHERE id = $1', [req.user.id]);
    res.json({ ok: true });
  } catch (err) {
    fail(res, err);
  }
});

router.post('/2fa/disable', requireAuth, async (req, res) => {
  try {
    const { password } = z.object({ password: z.string() }).parse(req.body);
    if (!(await bcrypt.compare(password, req.user.password_hash))) {
      return res.status(401).json({ error: 'Wrong password' });
    }
    await db.query('UPDATE users SET totp_enabled = FALSE, totp_secret = NULL WHERE id = $1', [req.user.id]);
    res.json({ ok: true });
  } catch (err) {
    fail(res, err);
  }
});

// ---- Fingerprint login ----
// The app calls /biometric/enable once while logged in, stores the returned device token in the
// phone's secure storage behind the fingerprint lock, and later exchanges it for an access token.
router.post('/biometric/enable', requireAuth, async (req, res) => {
  try {
    const { deviceName } = z.object({ deviceName: z.string().optional() }).parse(req.body || {});
    const token = crypto.randomBytes(32).toString('hex');
    const hash = crypto.createHash('sha256').update(token).digest('hex');
    await db.tx(async (client) => {
      await client.query(
        'INSERT INTO device_tokens (user_id, token_hash, device_name) VALUES ($1, $2, $3)',
        [req.user.id, hash, deviceName || null]
      );
      await client.query('UPDATE users SET biometric_enabled = TRUE WHERE id = $1', [req.user.id]);
    });
    res.json({ deviceToken: token });
  } catch (err) {
    fail(res, err);
  }
});

router.post('/biometric/login', async (req, res) => {
  try {
    const { deviceToken } = z.object({ deviceToken: z.string().length(64) }).parse(req.body);
    const hash = crypto.createHash('sha256').update(deviceToken).digest('hex');
    const { rows } = await db.query(
      `UPDATE device_tokens SET last_used_at = now() WHERE token_hash = $1 RETURNING user_id`,
      [hash]
    );
    if (!rows[0]) return res.status(401).json({ error: 'This device is no longer trusted. Log in with your password.' });

    const userRes = await db.query('SELECT * FROM users WHERE id = $1', [rows[0].user_id]);
    const user = userRes.rows[0];
    res.json({ status: 'ok', accessToken: signAccessToken(user) });
  } catch (err) {
    fail(res, err);
  }
});

router.post('/biometric/disable', requireAuth, async (req, res) => {
  await db.tx(async (client) => {
    await client.query('DELETE FROM device_tokens WHERE user_id = $1', [req.user.id]);
    await client.query('UPDATE users SET biometric_enabled = FALSE WHERE id = $1', [req.user.id]);
  });
  res.json({ ok: true });
});

module.exports = router;
