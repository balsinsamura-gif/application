const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { requireAuth, requireVerified } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireVerified);

function bad(res, err) {
  if (err instanceof z.ZodError) {
    return res.status(400).json({ error: err.issues.map((i) => i.message).join('; ') });
  }
  console.error(err);
  return res.status(500).json({ error: 'Something went wrong' });
}

// Inbox: one row per person I have talked with, with the last message and unread count
router.get('/conversations', async (req, res) => {
  const { rows } = await db.query(
    `WITH mine AS (
       SELECT m.*, CASE WHEN m.sender_id = $1 THEN m.recipient_id ELSE m.sender_id END AS other_id
       FROM messages m WHERE m.sender_id = $1 OR m.recipient_id = $1
     ),
     last_msg AS (
       SELECT DISTINCT ON (other_id) other_id, body, created_at, sender_id
       FROM mine ORDER BY other_id, id DESC
     ),
     unread AS (
       SELECT sender_id AS other_id, COUNT(*)::int AS n
       FROM messages WHERE recipient_id = $1 AND read_at IS NULL GROUP BY sender_id
     )
     SELECT l.other_id AS "userId", COALESCE(bp.company_name, ip.full_name) AS name,
            l.body AS "lastMessage", l.created_at AS "lastAt", (l.sender_id = $1) AS "lastFromMe",
            COALESCE(un.n, 0) AS unread,
            CASE WHEN u.call_enabled THEN u.phone END AS phone
     FROM last_msg l
     JOIN users u ON u.id = l.other_id
     LEFT JOIN individual_profiles ip ON ip.user_id = u.id
     LEFT JOIN business_profiles bp ON bp.user_id = u.id
     LEFT JOIN unread un ON un.other_id = l.other_id
     ORDER BY l.created_at DESC`,
    [req.user.id]
  );
  res.json(rows);
});

// Total unread, for a badge on the Messages tab
router.get('/unread-count', async (req, res) => {
  const { rows } = await db.query(
    'SELECT COUNT(*)::int AS n FROM messages WHERE recipient_id = $1 AND read_at IS NULL',
    [req.user.id]
  );
  res.json({ unread: rows[0].n });
});

// Conversation with one person. `after` returns only newer messages, so the app can poll cheaply.
router.get('/with/:userId', async (req, res) => {
  try {
    const other = z.string().uuid().parse(req.params.userId);
    const after = z.coerce.number().int().min(0).default(0).parse(req.query.after);

    const person = await db.query(
      `SELECT u.id, COALESCE(bp.company_name, ip.full_name) AS name,
              CASE WHEN u.call_enabled THEN u.phone END AS phone
       FROM users u
       LEFT JOIN individual_profiles ip ON ip.user_id = u.id
       LEFT JOIN business_profiles bp ON bp.user_id = u.id
       WHERE u.id = $1`,
      [other]
    );
    if (!person.rows[0]) return res.status(404).json({ error: 'Person not found' });

    const { rows } = await db.query(
      `SELECT id, sender_id = $1 AS mine, body, created_at AS "createdAt"
       FROM messages
       WHERE id > $3 AND ((sender_id = $1 AND recipient_id = $2) OR (sender_id = $2 AND recipient_id = $1))
       ORDER BY id ASC LIMIT 200`,
      [req.user.id, other, after]
    );

    await db.query(
      `UPDATE messages SET read_at = now()
       WHERE recipient_id = $1 AND sender_id = $2 AND read_at IS NULL`,
      [req.user.id, other]
    );
    res.json({ person: person.rows[0], messages: rows });
  } catch (err) {
    bad(res, err);
  }
});

router.post('/with/:userId', async (req, res) => {
  try {
    const other = z.string().uuid().parse(req.params.userId);
    const { body } = z.object({ body: z.string().trim().min(1).max(2000) }).parse(req.body);
    if (other === req.user.id) return res.status(400).json({ error: 'You cannot message yourself' });

    const exists = await db.query('SELECT 1 FROM users WHERE id = $1 AND email_verified AND phone_verified', [other]);
    if (!exists.rows[0]) return res.status(404).json({ error: 'Person not found' });

    const { rows } = await db.query(
      `INSERT INTO messages (sender_id, recipient_id, body) VALUES ($1, $2, $3)
       RETURNING id, TRUE AS mine, body, created_at AS "createdAt"`,
      [req.user.id, other, body]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    bad(res, err);
  }
});

module.exports = router;
