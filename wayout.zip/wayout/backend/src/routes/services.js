const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { requireAuth, requireVerified } = require('../middleware/auth');
const { chargeMobile } = require('../services/payments');

const router = express.Router();
router.use(requireAuth, requireVerified);

function bad(res, err) {
  if (err instanceof z.ZodError) {
    return res.status(400).json({ error: err.issues.map((i) => i.message).join('; ') });
  }
  console.error(err);
  return res.status(500).json({ error: 'Something went wrong' });
}

const createSchema = z.object({
  providerId: z.string().uuid(),
  professionId: z.number().int(),
  description: z.string().min(3).max(1000),
  address: z.string().min(3).max(300),
  scheduledAt: z.string().datetime({ offset: true }),
  hours: z.number().min(0.5).max(24).default(1),
});

// Ask one professional for a service (caregiver, chef, tutor, housekeeper...)
router.post('/', async (req, res) => {
  try {
    const d = createSchema.parse(req.body);
    if (d.providerId === req.user.id) return res.status(400).json({ error: 'You cannot book yourself' });
    if (new Date(d.scheduledAt) <= new Date()) {
      return res.status(400).json({ error: 'Pick a date and time in the future' });
    }

    const { rows } = await db.query(
      `SELECT up.rate, up.rate_unit, p.uses_rate, p.name AS profession_name,
              u.email_verified AND u.phone_verified AS verified
       FROM user_professions up
       JOIN professions p ON p.id = up.profession_id
       JOIN users u ON u.id = up.user_id
       WHERE up.user_id = $1 AND up.profession_id = $2`,
      [d.providerId, d.professionId]
    );
    const offer = rows[0];
    if (!offer || !offer.verified) {
      return res.status(404).json({ error: 'This professional does not offer that service' });
    }
    if (!offer.uses_rate) {
      return res.status(400).json({ error: 'Deliveries are requested from the New delivery screen' });
    }

    const rate = Number(offer.rate);
    const price = offer.rate_unit === 'per_hour' ? rate * d.hours : rate;

    const inserted = await db.query(
      `INSERT INTO service_requests
        (customer_id, provider_id, profession_id, description, address, scheduled_at, hours, price)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.user.id, d.providerId, d.professionId, d.description, d.address, d.scheduledAt, d.hours, Math.round(price * 100) / 100]
    );
    res.status(201).json(inserted.rows[0]);
  } catch (err) {
    bad(res, err);
  }
});

// My bookings, as customer or as professional
router.get('/mine', async (req, res) => {
  const { rows } = await db.query(
    `SELECT s.*, p.name AS profession_name,
            (s.customer_id = $1) AS i_am_customer,
            (r.id IS NOT NULL) AS rated,
            cp.id AS other_user_id,
            COALESCE(cbp.company_name, cip.full_name) AS other_name,
            CASE WHEN cp.call_enabled THEN cp.phone END AS other_phone
     FROM service_requests s
     JOIN professions p ON p.id = s.profession_id
     LEFT JOIN ratings r ON r.service_id = s.id
     JOIN users cp ON cp.id = CASE WHEN s.customer_id = $1 THEN s.provider_id ELSE s.customer_id END
     LEFT JOIN individual_profiles cip ON cip.user_id = cp.id
     LEFT JOIN business_profiles cbp ON cbp.user_id = cp.id
     WHERE s.customer_id = $1 OR s.provider_id = $1
     ORDER BY s.created_at DESC LIMIT 100`,
    [req.user.id]
  );
  res.json(rows);
});

async function loadFor(req, res, role) {
  const { rows } = await db.query('SELECT * FROM service_requests WHERE id = $1', [req.params.id]);
  const s = rows[0];
  const ownerId = role === 'provider' ? s?.provider_id : s?.customer_id;
  if (!s || ownerId !== req.user.id) {
    res.status(404).json({ error: 'Booking not found' });
    return null;
  }
  return s;
}

// Professional accepts or declines a request
router.post('/:id/respond', async (req, res) => {
  try {
    const { accept } = z.object({ accept: z.boolean() }).parse(req.body);
    const s = await loadFor(req, res, 'provider');
    if (!s) return;
    if (s.status !== 'requested') return res.status(409).json({ error: `This request is already ${s.status}` });

    const updated = await db.query(
      `UPDATE service_requests SET status = $1, updated_at = now() WHERE id = $2 RETURNING *`,
      [accept ? 'accepted' : 'declined', s.id]
    );
    res.json(updated.rows[0]);
  } catch (err) {
    bad(res, err);
  }
});

// Customer pays by mobile money once the professional has accepted
router.post('/:id/pay', async (req, res) => {
  try {
    const { msisdn } = z.object({ msisdn: z.string().regex(/^\+?[0-9]{8,15}$/) }).parse(req.body);
    const s = await loadFor(req, res, 'customer');
    if (!s) return;
    if (s.status !== 'accepted') return res.status(409).json({ error: 'You can pay after the professional accepts' });
    if (s.paid) return res.status(400).json({ error: 'Already paid' });

    const result = await chargeMobile({
      userId: req.user.id,
      purpose: 'service',
      referenceId: s.id,
      amount: s.price,
      msisdn,
    });
    if (result.status === 'succeeded') {
      await db.query('UPDATE service_requests SET paid = TRUE, updated_at = now() WHERE id = $1', [s.id]);
    }
    res.json({ paymentStatus: result.status, paymentId: result.paymentId });
  } catch (err) {
    bad(res, err);
  }
});

// Professional marks the job done (after payment). Customer can cancel before paying.
router.post('/:id/status', async (req, res) => {
  try {
    const { status } = z.object({ status: z.enum(['completed', 'cancelled']) }).parse(req.body);
    const s = await loadFor(req, res, status === 'completed' ? 'provider' : 'customer');
    if (!s) return;

    if (status === 'completed') {
      if (s.status !== 'accepted' || !s.paid) {
        return res.status(409).json({ error: 'The job can be completed once it is accepted and paid' });
      }
    } else {
      if (!['requested', 'accepted'].includes(s.status)) {
        return res.status(409).json({ error: `Cannot cancel a ${s.status} booking` });
      }
      if (s.paid) {
        return res.status(409).json({ error: 'A paid booking cannot be cancelled in the app yet. Message the professional.' });
      }
    }

    const updated = await db.query(
      `UPDATE service_requests SET status = $1, updated_at = now() WHERE id = $2 RETURNING *`,
      [status, s.id]
    );
    res.json(updated.rows[0]);
  } catch (err) {
    bad(res, err);
  }
});

router.post('/:id/rating', async (req, res) => {
  try {
    const { stars, comment } = z
      .object({ stars: z.number().int().min(1).max(5), comment: z.string().max(500).optional() })
      .parse(req.body);
    const s = await loadFor(req, res, 'customer');
    if (!s) return;
    if (s.status !== 'completed') return res.status(400).json({ error: 'You can rate a service after it is completed' });

    await db.query(
      `INSERT INTO ratings (service_id, rater_id, rated_id, stars, comment) VALUES ($1,$2,$3,$4,$5)`,
      [s.id, req.user.id, s.provider_id, stars, comment || null]
    );
    res.status(201).json({ ok: true });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'You already rated this service' });
    bad(res, err);
  }
});

module.exports = router;
