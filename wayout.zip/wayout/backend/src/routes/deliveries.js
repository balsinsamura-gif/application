const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { requireAuth, requireVerified } = require('../middleware/auth');
const { distanceKm, priceForDistance } = require('../services/pricing');
const { chargeMobile } = require('../services/payments');

const router = express.Router();
router.use(requireAuth, requireVerified);

const coord = z.object({
  address: z.string().min(2),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
});

const createSchema = z.object({
  pickup: coord,
  dropoff: coord,
  mode: z.enum(['send', 'receive']).default('send'),
  transportTypeId: z.number().int().optional(),
  itemDescription: z.string().optional(),
  recipientName: z.string().optional(),
  recipientPhone: z.string().optional(),
});

function bad(res, err) {
  if (err instanceof z.ZodError) {
    return res.status(400).json({ error: err.issues.map((i) => i.message).join('; ') });
  }
  console.error(err);
  return res.status(500).json({ error: 'Something went wrong' });
}

// Price quote by distance, before the customer commits
router.post('/quote', (req, res) => {
  try {
    const { pickup, dropoff } = z.object({ pickup: coord, dropoff: coord }).parse(req.body);
    const km = distanceKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng);
    res.json({ distanceKm: Math.round(km * 100) / 100, price: priceForDistance(km) });
  } catch (err) {
    bad(res, err);
  }
});

router.post('/', async (req, res) => {
  try {
    const d = createSchema.parse(req.body);
    const km = distanceKm(d.pickup.lat, d.pickup.lng, d.dropoff.lat, d.dropoff.lng);
    const { rows } = await db.query(
      `INSERT INTO deliveries
        (requester_id, pickup_address, dropoff_address, pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
         distance_km, price, transport_type_id, item_description, recipient_name, recipient_phone, mode)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
      [
        req.user.id,
        d.pickup.address,
        d.dropoff.address,
        d.pickup.lat,
        d.pickup.lng,
        d.dropoff.lat,
        d.dropoff.lng,
        Math.round(km * 100) / 100,
        priceForDistance(km),
        d.transportTypeId || null,
        d.itemDescription || null,
        d.recipientName || null,
        d.recipientPhone || null,
        d.mode,
      ]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    bad(res, err);
  }
});

// Pay for a delivery with mobile money. Providers only see paid deliveries.
router.post('/:id/pay', async (req, res) => {
  try {
    const { msisdn } = z.object({ msisdn: z.string().regex(/^\+?[0-9]{8,15}$/) }).parse(req.body);
    const { rows } = await db.query(
      `SELECT * FROM deliveries WHERE id = $1 AND requester_id = $2`,
      [req.params.id, req.user.id]
    );
    const delivery = rows[0];
    if (!delivery) return res.status(404).json({ error: 'Delivery not found' });
    if (delivery.paid) return res.status(400).json({ error: 'Already paid' });
    if (delivery.status === 'cancelled') return res.status(400).json({ error: 'Delivery is cancelled' });

    const result = await chargeMobile({
      userId: req.user.id,
      purpose: 'delivery',
      referenceId: delivery.id,
      amount: delivery.price,
      msisdn,
    });

    if (result.status === 'succeeded') {
      await db.query('UPDATE deliveries SET paid = TRUE, updated_at = now() WHERE id = $1', [delivery.id]);
    }
    res.json({ paymentStatus: result.status, paymentId: result.paymentId });
  } catch (err) {
    bad(res, err);
  }
});

// My deliveries: ones I requested and ones I carry
router.get('/mine', async (req, res) => {
  const { rows } = await db.query(
    `SELECT d.*, t.name AS transport_name,
            (d.requester_id = $1) AS i_am_requester,
            (r.id IS NOT NULL) AS rated,
            CASE WHEN cp.call_enabled THEN cp.phone END AS other_phone,
            cp.id AS other_user_id,
            COALESCE(cbp.company_name, cip.full_name) AS other_name
     FROM deliveries d
     LEFT JOIN transport_types t ON t.id = d.transport_type_id
     LEFT JOIN ratings r ON r.delivery_id = d.id
     LEFT JOIN users cp ON cp.id = CASE WHEN d.requester_id = $1 THEN d.provider_id ELSE d.requester_id END
     LEFT JOIN individual_profiles cip ON cip.user_id = cp.id
     LEFT JOIN business_profiles cbp ON cbp.user_id = cp.id
     WHERE d.requester_id = $1 OR d.provider_id = $1
     ORDER BY d.created_at DESC LIMIT 100`,
    [req.user.id]
  );
  res.json(rows);
});

// Can this account carry deliveries of the given transport type right now?
async function providerCapability(user, transportTypeId, client = db) {
  if (user.account_type === 'individual') {
    const { rows } = await client.query(
      `SELECT 1 FROM user_professions up JOIN professions p ON p.id = up.profession_id
       WHERE up.user_id = $1 AND p.name = 'Delivery service'`,
      [user.id]
    );
    return rows.length > 0
      ? { ok: true }
      : { ok: false, reason: 'Add the "Delivery service" profession to your profile to accept deliveries' };
  }

  // Businesses need an active slot for the transport type, with free capacity
  const typeFilter = transportTypeId || null;
  const slots = await client.query(
    `SELECT COALESCE(SUM(quantity), 0)::int AS total FROM slots
     WHERE business_id = $1 AND expires_at > now()
       AND ($2::int IS NULL OR transport_type_id = $2)`,
    [user.id, typeFilter]
  );
  const inUse = await client.query(
    `SELECT COUNT(*)::int AS n FROM deliveries
     WHERE provider_id = $1 AND status IN ('accepted', 'picked_up')
       AND ($2::int IS NULL OR transport_type_id = $2)`,
    [user.id, typeFilter]
  );
  if (slots.rows[0].total === 0) {
    return { ok: false, reason: 'Buy a transport slot to accept deliveries' };
  }
  if (inUse.rows[0].n >= slots.rows[0].total) {
    return { ok: false, reason: 'All your slots are in use. Buy more slots or finish a delivery.' };
  }
  return { ok: true };
}

// Open, paid deliveries a provider may take
router.get('/available', async (req, res) => {
  const { rows } = await db.query(
    `SELECT d.id, d.pickup_address, d.dropoff_address, d.distance_km, d.price, d.mode,
            d.item_description, d.transport_type_id, t.name AS transport_name, d.created_at
     FROM deliveries d LEFT JOIN transport_types t ON t.id = d.transport_type_id
     WHERE d.status = 'requested' AND d.paid = TRUE AND d.requester_id <> $1
     ORDER BY d.created_at DESC LIMIT 50`,
    [req.user.id]
  );
  res.json(rows);
});

router.post('/:id/accept', async (req, res) => {
  try {
    const result = await db.tx(async (client) => {
      const found = await client.query(
        `SELECT * FROM deliveries WHERE id = $1 FOR UPDATE`,
        [req.params.id]
      );
      const delivery = found.rows[0];
      if (!delivery) return { code: 404, error: 'Delivery not found' };
      if (delivery.requester_id === req.user.id) return { code: 400, error: 'You cannot accept your own delivery' };
      if (delivery.status !== 'requested' || !delivery.paid) {
        return { code: 409, error: 'This delivery is no longer available' };
      }
      const cap = await providerCapability(req.user, delivery.transport_type_id, client);
      if (!cap.ok) return { code: 403, error: cap.reason };

      const updated = await client.query(
        `UPDATE deliveries SET provider_id = $1, status = 'accepted', updated_at = now()
         WHERE id = $2 RETURNING *`,
        [req.user.id, delivery.id]
      );
      return { code: 200, body: updated.rows[0] };
    });
    if (result.error) return res.status(result.code).json({ error: result.error });
    res.json(result.body);
  } catch (err) {
    bad(res, err);
  }
});

const transitions = {
  picked_up: { from: ['accepted'], actor: 'provider' },
  delivered: { from: ['picked_up'], actor: 'provider' },
  cancelled: { from: ['requested', 'accepted'], actor: 'requester' },
};

router.post('/:id/status', async (req, res) => {
  try {
    const { status } = z.object({ status: z.enum(['picked_up', 'delivered', 'cancelled']) }).parse(req.body);
    const rule = transitions[status];

    const { rows } = await db.query('SELECT * FROM deliveries WHERE id = $1', [req.params.id]);
    const delivery = rows[0];
    if (!delivery) return res.status(404).json({ error: 'Delivery not found' });

    const actorId = rule.actor === 'provider' ? delivery.provider_id : delivery.requester_id;
    if (actorId !== req.user.id) {
      return res.status(403).json({ error: `Only the ${rule.actor} can do this` });
    }
    if (!rule.from.includes(delivery.status)) {
      return res.status(409).json({ error: `Cannot change from ${delivery.status} to ${status}` });
    }

    const updated = await db.query(
      `UPDATE deliveries SET status = $1, updated_at = now() WHERE id = $2 RETURNING *`,
      [status, delivery.id]
    );
    res.json(updated.rows[0]);
  } catch (err) {
    bad(res, err);
  }
});

// ---- Live tracking ----
// The courier's phone posts its position while the delivery is active.
router.post('/:id/location', async (req, res) => {
  try {
    const { lat, lng } = z
      .object({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180) })
      .parse(req.body);
    const { rows } = await db.query('SELECT * FROM deliveries WHERE id = $1', [req.params.id]);
    const delivery = rows[0];
    if (!delivery || delivery.provider_id !== req.user.id) {
      return res.status(404).json({ error: 'Delivery not found' });
    }
    if (!['accepted', 'picked_up'].includes(delivery.status)) {
      return res.status(409).json({ error: 'Location sharing is only for active deliveries' });
    }
    await db.query(
      `INSERT INTO delivery_locations (delivery_id, lat, lng) VALUES ($1, $2, $3)
       ON CONFLICT (delivery_id) DO UPDATE SET lat = EXCLUDED.lat, lng = EXCLUDED.lng, updated_at = now()`,
      [delivery.id, lat, lng]
    );
    res.json({ ok: true });
  } catch (err) {
    bad(res, err);
  }
});

// Both sides read the route points and the courier's latest position to draw the map.
router.get('/:id/tracking', async (req, res) => {
  const { rows } = await db.query(
    `SELECT d.id, d.status, d.requester_id, d.provider_id,
            d.pickup_address, d.pickup_lat, d.pickup_lng,
            d.dropoff_address, d.dropoff_lat, d.dropoff_lng,
            l.lat AS courier_lat, l.lng AS courier_lng, l.updated_at AS courier_updated_at
     FROM deliveries d LEFT JOIN delivery_locations l ON l.delivery_id = d.id
     WHERE d.id = $1`,
    [req.params.id]
  );
  const d = rows[0];
  if (!d || (d.requester_id !== req.user.id && d.provider_id !== req.user.id)) {
    return res.status(404).json({ error: 'Delivery not found' });
  }
  const active = ['accepted', 'picked_up'].includes(d.status);
  res.json({
    id: d.id,
    status: d.status,
    iAmCourier: d.provider_id === req.user.id,
    pickup: { address: d.pickup_address, lat: d.pickup_lat, lng: d.pickup_lng },
    dropoff: { address: d.dropoff_address, lat: d.dropoff_lat, lng: d.dropoff_lng },
    // The courier's position is only shared while the delivery is active
    courier: active && d.courier_lat !== null ? { lat: d.courier_lat, lng: d.courier_lng, updatedAt: d.courier_updated_at } : null,
  });
});

// Customer rates the service after delivery
router.post('/:id/rating', async (req, res) => {
  try {
    const { stars, comment } = z
      .object({ stars: z.number().int().min(1).max(5), comment: z.string().max(500).optional() })
      .parse(req.body);

    const { rows } = await db.query('SELECT * FROM deliveries WHERE id = $1', [req.params.id]);
    const delivery = rows[0];
    if (!delivery || delivery.requester_id !== req.user.id) {
      return res.status(404).json({ error: 'Delivery not found' });
    }
    if (delivery.status !== 'delivered') {
      return res.status(400).json({ error: 'You can rate a delivery after it is delivered' });
    }

    await db.query(
      `INSERT INTO ratings (delivery_id, rater_id, rated_id, stars, comment) VALUES ($1,$2,$3,$4,$5)`,
      [delivery.id, req.user.id, delivery.provider_id, stars, comment || null]
    );
    res.status(201).json({ ok: true });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'You already rated this delivery' });
    bad(res, err);
  }
});

module.exports = router;
