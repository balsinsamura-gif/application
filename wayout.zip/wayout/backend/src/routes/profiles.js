const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const { listProfessions } = require('../services/professions');

const router = express.Router();

async function loadProfile(user) {
  const table = user.account_type === 'individual' ? 'individual_profiles' : 'business_profiles';
  const profile = (await db.query(`SELECT * FROM ${table} WHERE user_id = $1`, [user.id])).rows[0];
  const categories = (
    await db.query(
      `SELECT c.id, c.name FROM profile_categories pc
       JOIN categories c ON c.id = pc.category_id WHERE pc.user_id = $1 ORDER BY c.name`,
      [user.id]
    )
  ).rows;
  const rating = (
    await db.query(
      `SELECT COALESCE(ROUND(AVG(stars)::numeric, 2), 0) AS average, COUNT(*)::int AS count
       FROM ratings WHERE rated_id = $1`,
      [user.id]
    )
  ).rows[0];
  const professions = await listProfessions(db, user.id);
  return { profile, categories, professions, rating: { average: Number(rating.average), count: rating.count } };
}

// Public lookups used by the app to build selectors
router.get('/meta/categories', async (req, res) => {
  const type = req.query.type;
  const { rows } = await db.query(
    `SELECT id, name, applies_to FROM categories
     WHERE $1::text IS NULL OR applies_to IN ($1, 'both') ORDER BY name`,
    [type === 'individual' || type === 'business' ? type : null]
  );
  res.json(rows);
});

router.get('/meta/transport-types', async (req, res) => {
  const { rows } = await db.query('SELECT id, name, slot_price FROM transport_types ORDER BY slot_price');
  res.json(rows);
});

// Own account
router.get('/me', requireAuth, async (req, res) => {
  const u = req.user;
  const details = await loadProfile(u);
  res.json({
    id: u.id,
    accountType: u.account_type,
    email: u.email,
    phone: u.phone,
    emailVerified: u.email_verified,
    phoneVerified: u.phone_verified,
    twoFactorEnabled: u.totp_enabled,
    biometricEnabled: u.biometric_enabled,
    callEnabled: u.call_enabled,
    shareSlug: u.share_slug,
    shareLink: `/p/${u.share_slug}`,
    referralCode: u.referral_code,
    ...details,
  });
});

const updateSchema = z.object({
  fullName: z.string().min(2).optional(),
  bio: z.string().optional(),
  companyName: z.string().min(2).optional(),
  registrationNo: z.string().optional(),
  contactPerson: z.string().optional(),
  description: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  callEnabled: z.boolean().optional(),
  categoryIds: z.array(z.number().int()).optional(),
});

router.put('/me', requireAuth, async (req, res) => {
  try {
    const d = updateSchema.parse(req.body);
    const u = req.user;

    await db.tx(async (client) => {
      if (d.callEnabled !== undefined) {
        await client.query('UPDATE users SET call_enabled = $1 WHERE id = $2', [d.callEnabled, u.id]);
      }
      if (u.account_type === 'individual') {
        await client.query(
          `UPDATE individual_profiles SET
             full_name = COALESCE($2, full_name), bio = COALESCE($3, bio),
             address = COALESCE($4, address), city = COALESCE($5, city)
           WHERE user_id = $1`,
          [u.id, d.fullName, d.bio, d.address, d.city]
        );
      } else {
        await client.query(
          `UPDATE business_profiles SET
             company_name = COALESCE($2, company_name), registration_no = COALESCE($3, registration_no),
             contact_person = COALESCE($4, contact_person), description = COALESCE($5, description),
             address = COALESCE($6, address), city = COALESCE($7, city)
           WHERE user_id = $1`,
          [u.id, d.companyName, d.registrationNo, d.contactPerson, d.description, d.address, d.city]
        );
      }
      if (d.categoryIds) {
        await client.query('DELETE FROM profile_categories WHERE user_id = $1', [u.id]);
        await client.query(
          `INSERT INTO profile_categories (user_id, category_id)
           SELECT $1, id FROM categories WHERE id = ANY($2::int[]) AND applies_to IN ($3, 'both')`,
          [u.id, d.categoryIds, u.account_type]
        );
      }
    });
    res.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: err.issues.map((i) => i.message).join('; ') });
    }
    console.error(err);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

// Public profile page data, reachable from a shareable link (/p/:slug in the app)
router.get('/profiles/:slug', optionalAuth, async (req, res) => {
  const { rows } = await db.query('SELECT * FROM users WHERE share_slug = $1', [req.params.slug]);
  const user = rows[0];
  if (!user) return res.status(404).json({ error: 'Profile not found' });

  const { profile, categories, professions, rating } = await loadProfile(user);
  const reviews = (
    await db.query(
      `SELECT stars, comment, created_at FROM ratings WHERE rated_id = $1 ORDER BY created_at DESC LIMIT 20`,
      [user.id]
    )
  ).rows;

  const isBusiness = user.account_type === 'business';
  const viewerVerified = !!(req.user && req.user.email_verified && req.user.phone_verified);
  res.json({
    userId: user.id,
    accountType: user.account_type,
    name: isBusiness ? profile.company_name : profile.full_name,
    professions,
    description: isBusiness ? profile.description : profile.bio,
    city: profile.city,
    categories,
    rating,
    reviews,
    // The phone number is only shown when the owner allows calls AND the viewer is a
    // logged-in, verified account. Anyone holding the link can still see the rest of the profile.
    callEnabled: user.call_enabled,
    phone: user.call_enabled && viewerVerified ? user.phone : null,
    memberSince: user.created_at,
  });
});

module.exports = router;
