const express = require('express');
const { z } = require('zod');
const db = require('../db');
const config = require('../config');
const { requireAuth, requireType, requireVerified } = require('../middleware/auth');
const { chargeMobile } = require('../services/payments');

const router = express.Router();
router.use(requireAuth, requireVerified, requireType('business'));

function bad(res, err) {
  if (err instanceof z.ZodError) {
    return res.status(400).json({ error: err.issues.map((i) => i.message).join('; ') });
  }
  console.error(err);
  return res.status(500).json({ error: 'Something went wrong' });
}

// ---- Transport slots ----
router.get('/slots', async (req, res) => {
  const { rows } = await db.query(
    `SELECT s.id, s.quantity, s.total_paid, s.starts_at, s.expires_at,
            (s.expires_at > now()) AS active, t.name AS transport_name
     FROM slots s JOIN transport_types t ON t.id = s.transport_type_id
     WHERE s.business_id = $1 ORDER BY s.expires_at DESC`,
    [req.user.id]
  );
  res.json(rows);
});

const buySchema = z.object({
  transportTypeId: z.number().int(),
  quantity: z.number().int().min(1).max(500),
  months: z.number().int().min(1).max(12),
  msisdn: z.string().regex(/^\+?[0-9]{8,15}$/),
});

// Buy slots for any form of transportation, paid with mobile money
router.post('/slots', async (req, res) => {
  try {
    const d = buySchema.parse(req.body);
    const type = (await db.query('SELECT * FROM transport_types WHERE id = $1', [d.transportTypeId])).rows[0];
    if (!type) return res.status(404).json({ error: 'Transport type not found' });

    const total = Number(type.slot_price) * d.quantity * d.months;

    const result = await db.tx(async (client) => {
      const pay = await chargeMobile(
        { userId: req.user.id, purpose: 'slot', amount: total, msisdn: d.msisdn },
        client
      );
      if (pay.status !== 'succeeded') return { failed: true, pay };

      const slot = (
        await client.query(
          `INSERT INTO slots (business_id, transport_type_id, quantity, total_paid, payment_id, expires_at)
           VALUES ($1, $2, $3, $4, $5, now() + make_interval(months => $6::int)) RETURNING *`,
          [req.user.id, type.id, d.quantity, total, pay.paymentId, d.months]
        )
      ).rows[0];

      // Referral reward on the referred business's first slot purchase only
      if (req.user.referred_by) {
        const reward = Math.round(total * config.referralRewardPercent) / 100;
        await client.query(
          `INSERT INTO referral_rewards (referrer_id, referred_id, slot_id, amount)
           VALUES ($1, $2, $3, $4) ON CONFLICT (referred_id) DO NOTHING`,
          [req.user.referred_by, req.user.id, slot.id, reward]
        );
      }
      return { slot, pay };
    });

    if (result.failed) {
      return res.status(402).json({ error: 'Payment did not go through', paymentStatus: result.pay.status });
    }
    res.status(201).json({ slot: result.slot, totalPaid: total });
  } catch (err) {
    bad(res, err);
  }
});

// ---- Referrals (businesses and organizations only) ----
router.get('/referrals', async (req, res) => {
  const referred = (
    await db.query(
      `SELECT u.id, bp.company_name, u.created_at,
              (SELECT amount FROM referral_rewards r WHERE r.referred_id = u.id) AS reward
       FROM users u JOIN business_profiles bp ON bp.user_id = u.id
       WHERE u.referred_by = $1 ORDER BY u.created_at DESC`,
      [req.user.id]
    )
  ).rows;
  const total = (
    await db.query('SELECT COALESCE(SUM(amount), 0) AS total FROM referral_rewards WHERE referrer_id = $1', [
      req.user.id,
    ])
  ).rows[0].total;

  res.json({
    referralCode: req.user.referral_code,
    rewardPercent: config.referralRewardPercent,
    referred,
    totalRewards: Number(total),
  });
});

// Overview numbers for the company dashboard
router.get('/summary', async (req, res) => {
  const [deliveries, slots, rating] = await Promise.all([
    db.query(
      `SELECT
         COUNT(*) FILTER (WHERE requester_id = $1)::int AS requested,
         COUNT(*) FILTER (WHERE provider_id = $1 AND status = 'delivered')::int AS completed,
         COUNT(*) FILTER (WHERE provider_id = $1 AND status IN ('accepted','picked_up'))::int AS in_progress
       FROM deliveries WHERE requester_id = $1 OR provider_id = $1`,
      [req.user.id]
    ),
    db.query(
      `SELECT COALESCE(SUM(quantity), 0)::int AS active_slots FROM slots
       WHERE business_id = $1 AND expires_at > now()`,
      [req.user.id]
    ),
    db.query(
      `SELECT COALESCE(ROUND(AVG(stars)::numeric, 2), 0) AS average, COUNT(*)::int AS count
       FROM ratings WHERE rated_id = $1`,
      [req.user.id]
    ),
  ]);
  res.json({
    ...deliveries.rows[0],
    activeSlots: slots.rows[0].active_slots,
    rating: { average: Number(rating.rows[0].average), count: rating.rows[0].count },
  });
});

module.exports = router;
