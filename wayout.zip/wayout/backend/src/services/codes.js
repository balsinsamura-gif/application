const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('../db');
const config = require('../config');
const { sendSms, sendEmail } = require('./notify');

const CODE_TTL_MINUTES = 10;
const MAX_ATTEMPTS = 5;

function generateCode() {
  return String(crypto.randomInt(0, 1000000)).padStart(6, '0');
}

// Create and send a one-time code. channel: 'email' | 'phone' | 'login'
async function issueCode(user, channel) {
  const code = generateCode();
  const codeHash = await bcrypt.hash(code, 8);
  const expires = new Date(Date.now() + CODE_TTL_MINUTES * 60 * 1000);

  // Invalidate earlier unused codes for the same channel
  await db.query(
    'UPDATE verification_codes SET used = TRUE WHERE user_id = $1 AND channel = $2 AND used = FALSE',
    [user.id, channel]
  );
  await db.query(
    'INSERT INTO verification_codes (user_id, channel, code_hash, expires_at) VALUES ($1, $2, $3, $4)',
    [user.id, channel, codeHash, expires]
  );

  const text = `Your ${config.appName} verification code is ${code}. It expires in ${CODE_TTL_MINUTES} minutes.`;
  if (channel === 'email') {
    await sendEmail(user.email, `${config.appName} email verification`, text);
  } else {
    await sendSms(user.phone, text);
  }
}

// Returns true when the code is valid. Consumes it on success.
async function checkCode(userId, channel, code) {
  const { rows } = await db.query(
    `SELECT * FROM verification_codes
     WHERE user_id = $1 AND channel = $2 AND used = FALSE
     ORDER BY created_at DESC LIMIT 1`,
    [userId, channel]
  );
  const row = rows[0];
  if (!row) return false;
  if (new Date(row.expires_at) < new Date()) return false;
  if (row.attempts >= MAX_ATTEMPTS) return false;

  const ok = await bcrypt.compare(String(code), row.code_hash);
  if (!ok) {
    await db.query('UPDATE verification_codes SET attempts = attempts + 1 WHERE id = $1', [row.id]);
    return false;
  }
  await db.query('UPDATE verification_codes SET used = TRUE WHERE id = $1', [row.id]);
  return true;
}

module.exports = { issueCode, checkCode };
