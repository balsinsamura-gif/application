const crypto = require('crypto');
const db = require('../db');
const config = require('../config');

// Adapter interface: every provider exposes charge({ msisdn, amount, reference }) and returns
// { status: 'succeeded' | 'pending' | 'failed', providerRef }.
// Connect your real mobile money provider (for example Orange Money or Afrimoney in Sierra Leone)
// by adding an adapter here and setting PAYMENT_PROVIDER in .env.
const adapters = {
  mock: {
    async charge({ msisdn, amount, reference }) {
      console.log(`[MOCK PAYMENT] charge ${amount} from ${msisdn} ref=${reference}`);
      return { status: 'succeeded', providerRef: 'mock_' + crypto.randomBytes(6).toString('hex') };
    },
  },
};

function getAdapter() {
  const adapter = adapters[config.paymentProvider];
  if (!adapter) throw new Error(`Payment provider "${config.paymentProvider}" is not implemented`);
  return adapter;
}

// Records the payment and asks the provider to charge the phone number.
// `client` is optional so this can run inside a transaction.
async function chargeMobile({ userId, purpose, referenceId, amount, msisdn }, client = db) {
  const { rows } = await client.query(
    `INSERT INTO payments (user_id, purpose, reference_id, amount, msisdn, provider)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
    [userId, purpose, referenceId || null, amount, msisdn, config.paymentProvider]
  );
  const paymentId = rows[0].id;

  const result = await getAdapter().charge({ msisdn, amount, reference: paymentId });
  await client.query('UPDATE payments SET status = $1, provider_ref = $2 WHERE id = $3', [
    result.status,
    result.providerRef || null,
    paymentId,
  ]);
  return { paymentId, ...result };
}

module.exports = { chargeMobile };
