const config = require('../config');

// Development adapters print the message to the server log.
// Replace the bodies below with a real SMS gateway and email service in production.
async function sendSms(phone, message) {
  if (config.smsProvider === 'console') {
    console.log(`[SMS to ${phone}] ${message}`);
    return;
  }
  throw new Error(`SMS provider "${config.smsProvider}" is not implemented yet`);
}

async function sendEmail(to, subject, body) {
  if (config.emailProvider === 'console') {
    console.log(`[EMAIL to ${to}] ${subject}\n${body}`);
    return;
  }
  throw new Error(`Email provider "${config.emailProvider}" is not implemented yet`);
}

module.exports = { sendSms, sendEmail };
