const { z } = require('zod');

// One profession a user offers. Delivery has no rate because it is priced by distance.
const professionItem = z.object({
  professionId: z.number().int(),
  rate: z.number().min(0).max(100000000).optional(),
  rateUnit: z.enum(['per_hour', 'per_visit']).optional(),
  summary: z.string().max(500).optional(),
});

const professionList = z.array(professionItem).max(10);

// Replaces the user's professions with the given list. Runs inside a transaction client.
// Throws a validation error when a rate is missing for a profession that needs one.
async function setProfessions(client, userId, items) {
  const ids = items.map((i) => i.professionId);
  const found = await client.query('SELECT id, name, uses_rate FROM professions WHERE id = ANY($1::int[])', [ids]);
  const byId = new Map(found.rows.map((r) => [r.id, r]));

  for (const item of items) {
    const prof = byId.get(item.professionId);
    if (!prof) {
      const err = new Error('Unknown profession');
      err.status = 400;
      throw err;
    }
    if (prof.uses_rate && (item.rate === undefined || item.rate === null)) {
      const err = new Error(`Set your rate for ${prof.name}`);
      err.status = 400;
      throw err;
    }
  }

  await client.query('DELETE FROM user_professions WHERE user_id = $1', [userId]);
  for (const item of items) {
    const prof = byId.get(item.professionId);
    await client.query(
      `INSERT INTO user_professions (user_id, profession_id, rate, rate_unit, summary)
       VALUES ($1, $2, $3, $4, $5)`,
      [
        userId,
        prof.id,
        prof.uses_rate ? item.rate : null,
        prof.uses_rate ? item.rateUnit || 'per_hour' : 'per_hour',
        item.summary || null,
      ]
    );
  }
}

async function listProfessions(client, userId) {
  const { rows } = await client.query(
    `SELECT p.id AS "professionId", p.name, p.uses_rate AS "usesRate",
            up.rate, up.rate_unit AS "rateUnit", up.summary
     FROM user_professions up JOIN professions p ON p.id = up.profession_id
     WHERE up.user_id = $1 ORDER BY p.id`,
    [userId]
  );
  return rows.map((r) => ({ ...r, rate: r.rate === null ? null : Number(r.rate) }));
}

module.exports = { professionItem, professionList, setProfessions, listProfessions };
