const config = require('../config');

const EARTH_RADIUS_KM = 6371;
const toRad = (deg) => (deg * Math.PI) / 180;

// Straight-line distance between two coordinates, in kilometres
function distanceKm(lat1, lng1, lat2, lng2) {
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return EARTH_RADIUS_KM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Price depends on distance: base fee + per-km rate, never below the minimum fee
function priceForDistance(km) {
  const { baseFee, perKm, minFee } = config.pricing;
  const raw = baseFee + perKm * km;
  return Math.round(Math.max(raw, minFee) * 100) / 100;
}

module.exports = { distanceKm, priceForDistance };
