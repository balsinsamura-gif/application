const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../db');

// Access tokens are only issued after password + required verification steps.
function signAccessToken(user) {
  return jwt.sign({ sub: user.id, type: user.account_type }, config.jwtSecret, { expiresIn: '7d' });
}

// Short-lived token used between "password OK" and "2FA / login code OK"
function signChallengeToken(user) {
  return jwt.sign({ sub: user.id, purpose: 'challenge' }, config.jwtSecret, { expiresIn: '10m' });
}

function verifyChallengeToken(token) {
  const payload = jwt.verify(token, config.jwtSecret);
  if (payload.purpose !== 'challenge') throw new Error('Wrong token type');
  return payload;
}

async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Missing token' });

    const payload = jwt.verify(token, config.jwtSecret);
    if (payload.purpose) return res.status(401).json({ error: 'Invalid token' });

    const { rows } = await db.query('SELECT * FROM users WHERE id = $1', [payload.sub]);
    const user = rows[0];
    if (!user) return res.status(401).json({ error: 'Account not found' });

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// Like requireAuth, but anonymous visitors are allowed through with req.user unset.
async function optionalAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (token) {
      const payload = jwt.verify(token, config.jwtSecret);
      if (!payload.purpose) {
        const { rows } = await db.query('SELECT * FROM users WHERE id = $1', [payload.sub]);
        if (rows[0]) req.user = rows[0];
      }
    }
  } catch (err) {
    // Bad or expired token: treat the visitor as anonymous
  }
  next();
}

function requireType(type) {
  return (req, res, next) => {
    if (req.user.account_type !== type) {
      return res.status(403).json({ error: `Only ${type} accounts can do this` });
    }
    next();
  };
}

// Block features until both email and phone are verified
function requireVerified(req, res, next) {
  if (!req.user.email_verified || !req.user.phone_verified) {
    return res.status(403).json({ error: 'Verify your email and phone number first' });
  }
  next();
}

module.exports = {
  signAccessToken,
  signChallengeToken,
  verifyChallengeToken,
  requireAuth,
  optionalAuth,
  requireType,
  requireVerified,
};
