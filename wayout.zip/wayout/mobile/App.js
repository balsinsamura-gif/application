import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { AuthProvider, useAuth } from './src/lib/auth';
import { api } from './src/lib/api';
import { colors } from './src/ui';
import { LoginScreen, RegisterScreen, TwoFactorScreen, VerifyScreen, WelcomeScreen } from './src/screens/AuthScreens';
import HomeScreen from './src/screens/HomeScreen';
import ActivityScreen from './src/screens/ActivityScreen';
import NewDeliveryScreen from './src/screens/NewDeliveryScreen';
import BusinessScreen from './src/screens/BusinessScreen';
import TrackingScreen from './src/screens/TrackingScreen';
import { ChatScreen, ConversationsScreen } from './src/screens/ChatScreens';
import { FindScreen, ServiceRequestScreen } from './src/screens/ServiceScreens';
import { AccountScreen, PublicProfileScreen } from './src/screens/ProfileScreens';

const Stack = createNativeStackNavigator();
const Tabs = createBottomTabNavigator();

const headerStyle = { headerTintColor: colors.primary, headerStyle: { backgroundColor: colors.bg } };

function MainTabs() {
  const { me } = useAuth();
  const [unread, setUnread] = useState(0);

  // Badge on the Messages tab
  useEffect(() => {
    let active = true;
    const load = () =>
      api('/messages/unread-count')
        .then((d) => active && setUnread(d.unread))
        .catch(() => {});
    load();
    const timer = setInterval(load, 15000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);

  return (
    <Tabs.Navigator screenOptions={{ tabBarActiveTintColor: colors.primary, ...headerStyle }}>
      <Tabs.Screen name="Home" component={HomeScreen} options={{ tabBarIcon: () => <Text>🏠</Text> }} />
      <Tabs.Screen name="Activity" component={ActivityScreen} options={{ tabBarIcon: () => <Text>📦</Text> }} />
      <Tabs.Screen
        name="Messages"
        component={ConversationsScreen}
        options={{ tabBarIcon: () => <Text>💬</Text>, tabBarBadge: unread > 0 ? unread : undefined }}
      />
      {me.accountType === 'business' ? (
        <Tabs.Screen name="Business" component={BusinessScreen} options={{ tabBarIcon: () => <Text>🏢</Text> }} />
      ) : null}
      <Tabs.Screen name="Account" component={AccountScreen} options={{ tabBarIcon: () => <Text>👤</Text> }} />
    </Tabs.Navigator>
  );
}

// Lets links like wayout://p/abc123 open a public profile
const linking = {
  prefixes: ['wayout://'],
  config: { screens: { PublicProfile: 'p/:slug' } },
};

function Root() {
  const { ready, me } = useAuth();

  if (!ready) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <NavigationContainer linking={linking}>
      <Stack.Navigator screenOptions={headerStyle}>
        {me ? (
          <>
            <Stack.Screen name="Main" component={MainTabs} options={{ headerShown: false }} />
            <Stack.Screen name="NewDelivery" component={NewDeliveryScreen} options={{ title: 'New delivery' }} />
            <Stack.Screen name="PublicProfile" component={PublicProfileScreen} options={{ title: 'Profile' }} />
            <Stack.Screen name="Find" component={FindScreen} options={{ title: 'Find a professional' }} />
            <Stack.Screen name="ServiceRequest" component={ServiceRequestScreen} options={{ title: 'Request service' }} />
            <Stack.Screen name="Chat" component={ChatScreen} options={{ title: 'Chat' }} />
            <Stack.Screen name="Tracking" component={TrackingScreen} options={{ title: 'Live map' }} />
          </>
        ) : (
          <>
            <Stack.Screen name="Welcome" component={WelcomeScreen} options={{ headerShown: false }} />
            <Stack.Screen name="Register" component={RegisterScreen} options={{ title: 'Create account' }} />
            <Stack.Screen name="Verify" component={VerifyScreen} options={{ title: 'Verify' }} />
            <Stack.Screen name="Login" component={LoginScreen} options={{ title: 'Log in' }} />
            <Stack.Screen name="TwoFactor" component={TwoFactorScreen} options={{ title: 'Two-factor' }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <StatusBar style="dark" />
      <Root />
    </AuthProvider>
  );
}
