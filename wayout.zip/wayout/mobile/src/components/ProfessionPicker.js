import React from 'react';
import { View } from 'react-native';
import { Chip, Field, Muted, Row } from '../ui';

// value: [{ professionId, rate: '25', rateUnit: 'per_hour' | 'per_visit' }]
export function ProfessionPicker({ professions, value, onChange }) {
  const find = (id) => value.find((v) => v.professionId === id);

  const toggle = (id) => {
    if (find(id)) onChange(value.filter((v) => v.professionId !== id));
    else onChange([...value, { professionId: id, rate: '', rateUnit: 'per_hour' }]);
  };
  const patch = (id, change) => onChange(value.map((v) => (v.professionId === id ? { ...v, ...change } : v)));

  return (
    <View>
      <Row>
        {professions.map((p) => (
          <Chip key={p.id} label={p.name} selected={!!find(p.id)} onPress={() => toggle(p.id)} />
        ))}
      </Row>
      {professions
        .filter((p) => find(p.id))
        .map((p) => {
          const v = find(p.id);
          if (!p.usesRate) {
            return <Muted key={p.id}>{p.name}: priced by distance for each delivery.</Muted>;
          }
          return (
            <View key={p.id} style={{ marginTop: 6 }}>
              <Field
                label={`${p.name}: your rate`}
                value={v.rate}
                onChangeText={(t) => patch(p.id, { rate: t.replace(/[^0-9.]/g, '') })}
                keyboardType="decimal-pad"
                placeholder="e.g. 50"
              />
              <Row>
                <Chip label="Per hour" selected={v.rateUnit === 'per_hour'} onPress={() => patch(p.id, { rateUnit: 'per_hour' })} />
                <Chip label="Per visit" selected={v.rateUnit === 'per_visit'} onPress={() => patch(p.id, { rateUnit: 'per_visit' })} />
              </Row>
            </View>
          );
        })}
    </View>
  );
}

// Convert picker state into the API format. Returns an error message when a rate is missing.
export function professionsPayload(value, professions) {
  const items = [];
  for (const v of value) {
    const prof = professions.find((p) => p.id === v.professionId);
    if (prof && prof.usesRate) {
      const rate = parseFloat(v.rate);
      if (!(rate >= 0) || v.rate === '') return { error: `Enter your rate for ${prof.name}` };
      items.push({ professionId: v.professionId, rate, rateUnit: v.rateUnit });
    } else {
      items.push({ professionId: v.professionId });
    }
  }
  return { items };
}

// Existing professions from /me into picker state
export function pickerFromMe(list) {
  return (list || []).map((p) => ({
    professionId: p.professionId,
    rate: p.rate === null || p.rate === undefined ? '' : String(p.rate),
    rateUnit: p.rateUnit || 'per_hour',
  }));
}
