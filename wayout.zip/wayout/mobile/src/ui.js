import React from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

export const colors = {
  primary: '#0F766E',
  primaryDark: '#115E59',
  bg: '#F6F7F8',
  card: '#FFFFFF',
  text: '#111827',
  muted: '#6B7280',
  border: '#E5E7EB',
  danger: '#B91C1C',
  warn: '#B45309',
};

export function Screen({ children, scroll = true, style }) {
  const Body = scroll ? ScrollView : View;
  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Body style={{ flex: 1 }} contentContainerStyle={[styles.screen, style]} keyboardShouldPersistTaps="handled">
        {children}
      </Body>
    </KeyboardAvoidingView>
  );
}

export const H1 = ({ children }) => <Text style={styles.h1}>{children}</Text>;
export const H2 = ({ children }) => <Text style={styles.h2}>{children}</Text>;
export const Muted = ({ children, style }) => <Text style={[styles.muted, style]}>{children}</Text>;
export const ErrorText = ({ children }) => (children ? <Text style={styles.error}>{children}</Text> : null);

export function Card({ children, style }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Field({ label, ...props }) {
  return (
    <View style={{ marginBottom: 12 }}>
      {label ? <Text style={styles.label}>{label}</Text> : null}
      <TextInput placeholderTextColor="#9CA3AF" style={styles.input} autoCapitalize="none" {...props} />
    </View>
  );
}

export function Button({ title, onPress, kind = 'primary', loading, disabled, style }) {
  const bg = kind === 'primary' ? colors.primary : kind === 'danger' ? colors.danger : '#fff';
  const fg = kind === 'secondary' ? colors.primary : '#fff';
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: bg, opacity: disabled ? 0.5 : pressed ? 0.85 : 1 },
        kind === 'secondary' && { borderWidth: 1.5, borderColor: colors.primary },
        style,
      ]}
    >
      {loading ? <ActivityIndicator color={fg} /> : <Text style={[styles.buttonText, { color: fg }]}>{title}</Text>}
    </Pressable>
  );
}

export function Chip({ label, selected, onPress }) {
  return (
    <Pressable onPress={onPress} style={[styles.chip, selected && styles.chipOn]}>
      <Text style={{ color: selected ? '#fff' : colors.text, fontSize: 14 }}>{label}</Text>
    </Pressable>
  );
}

export function Row({ children, style }) {
  return <View style={[{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' }, style]}>{children}</View>;
}

export const money = (n) => Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 2 });

const styles = StyleSheet.create({
  screen: { padding: 20, paddingBottom: 40 },
  h1: { fontSize: 26, fontWeight: '700', color: colors.text, marginBottom: 6 },
  h2: { fontSize: 18, fontWeight: '600', color: colors.text, marginBottom: 8, marginTop: 8 },
  muted: { color: colors.muted, fontSize: 14, marginBottom: 8 },
  error: { color: colors.danger, marginBottom: 10, fontSize: 14 },
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  label: { fontSize: 13, color: colors.muted, marginBottom: 4 },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 11,
    fontSize: 16,
    color: colors.text,
  },
  button: { borderRadius: 10, paddingVertical: 13, alignItems: 'center', marginTop: 6, marginBottom: 6 },
  buttonText: { fontSize: 16, fontWeight: '600' },
  chip: {
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: '#fff',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginRight: 8,
    marginBottom: 8,
  },
  chipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
});
