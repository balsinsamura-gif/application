import React, { useEffect, useState } from 'react';
import { api } from '../lib/api';
import { currentPlace, placeFromAddress } from '../lib/geo';
import { useAuth } from '../lib/auth';
import { Button, Card, Chip, ErrorText, Field, H1, H2, Muted, Row, Screen, money } from '../ui';

export default function NewDeliveryScreen({ navigation }) {
  const { me } = useAuth();
  const [mode, setMode] = useState('send');
  const [pickupText, setPickupText] = useState('');
  const [dropoffText, setDropoffText] = useState('');
  const [pickup, setPickup] = useState(null); // resolved place, set when using GPS
  const [transport, setTransport] = useState([]);
  const [transportId, setTransportId] = useState(null);
  const [item, setItem] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [msisdn, setMsisdn] = useState(me?.phone || '');
  const [quote, setQuote] = useState(null);
  const [places, setPlaces] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api('/meta/transport-types').then(setTransport).catch(() => {});
  }, []);

  // Any change to the route invalidates the quote
  const resetQuote = () => {
    setQuote(null);
    setPlaces(null);
  };

  async function useMyLocation() {
    setError('');
    try {
      const p = await currentPlace();
      setPickup(p);
      setPickupText(p.address);
      resetQuote();
    } catch (e) {
      setError(e.message);
    }
  }

  async function getQuote() {
    setError('');
    setBusy(true);
    try {
      const from = pickup && pickup.address === pickupText ? pickup : await placeFromAddress(pickupText);
      const to = await placeFromAddress(dropoffText);
      const q = await api('/deliveries/quote', { method: 'POST', body: { pickup: from, dropoff: to } });
      setPlaces({ pickup: from, dropoff: to });
      setQuote(q);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function confirmAndPay() {
    setError('');
    setBusy(true);
    try {
      const delivery = await api('/deliveries', {
        method: 'POST',
        body: {
          pickup: places.pickup,
          dropoff: places.dropoff,
          mode,
          transportTypeId: transportId || undefined,
          itemDescription: item || undefined,
          recipientName: recipientName || undefined,
          recipientPhone: recipientPhone || undefined,
        },
      });
      const pay = await api(`/deliveries/${delivery.id}/pay`, { method: 'POST', body: { msisdn } });
      if (pay.paymentStatus !== 'succeeded') {
        setError('Your payment did not go through. The delivery is saved; you can pay again from My deliveries.');
        return;
      }
      navigation.navigate('Main', { screen: 'Deliveries' });
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  const ready = pickupText.length > 2 && dropoffText.length > 2;

  return (
    <Screen>
      <H1>New delivery</H1>
      <Row>
        <Chip label="Send a package" selected={mode === 'send'} onPress={() => setMode('send')} />
        <Chip label="Receive a package" selected={mode === 'receive'} onPress={() => setMode('receive')} />
      </Row>

      <Field
        label={mode === 'send' ? 'Pickup address' : 'Where to collect it from'}
        value={pickupText}
        onChangeText={(t) => {
          setPickupText(t);
          resetQuote();
        }}
        autoCapitalize="sentences"
      />
      <Button title="Use my current location" kind="secondary" onPress={useMyLocation} />
      <Field
        label={mode === 'send' ? 'Drop-off address' : 'Where to bring it'}
        value={dropoffText}
        onChangeText={(t) => {
          setDropoffText(t);
          resetQuote();
        }}
        autoCapitalize="sentences"
      />

      <H2>Transport</H2>
      <Row>
        <Chip label="Any" selected={transportId === null} onPress={() => setTransportId(null)} />
        {transport.map((t) => (
          <Chip key={t.id} label={t.name} selected={transportId === t.id} onPress={() => setTransportId(t.id)} />
        ))}
      </Row>

      <Field label="What is being delivered (optional)" value={item} onChangeText={setItem} autoCapitalize="sentences" />
      <Field label="Recipient name (optional)" value={recipientName} onChangeText={setRecipientName} autoCapitalize="words" />
      <Field label="Recipient phone (optional)" value={recipientPhone} onChangeText={setRecipientPhone} keyboardType="phone-pad" />

      <ErrorText>{error}</ErrorText>

      {!quote ? (
        <Button title="See price" onPress={getQuote} loading={busy} disabled={!ready} />
      ) : (
        <Card>
          <H2>Price</H2>
          <Muted>Distance: {quote.distanceKm} km</Muted>
          <H1>{money(quote.price)}</H1>
          <Field label="Mobile money number to pay from" value={msisdn} onChangeText={setMsisdn} keyboardType="phone-pad" />
          <Button title="Confirm and pay" onPress={confirmAndPay} loading={busy} disabled={msisdn.length < 8} />
        </Card>
      )}
    </Screen>
  );
}
