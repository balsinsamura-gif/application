import React, { useCallback, useState } from 'react';
import { Linking, RefreshControl, ScrollView, Text, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { api } from '../lib/api';
import { Button, Card, Chip, ErrorText, Field, H2, Muted, Row, colors, money } from '../ui';

const statusLabel = {
  requested: 'Waiting for a courier',
  accepted: 'Courier accepted',
  picked_up: 'On the way',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
};

function useList(path) {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    setRefreshing(true);
    try {
      setItems(await api(path));
      setError('');
    } catch (e) {
      setError(e.message);
    } finally {
      setRefreshing(false);
    }
  }, [path]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );
  return { items, error, refreshing, load, setError };
}

function DeliveryCard({ d, onChanged }) {
  const navigation = useNavigation();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [stars, setStars] = useState(0);
  const [comment, setComment] = useState('');
  const [rating, setRating] = useState(false);
  const [msisdn, setMsisdn] = useState('');
  const [paying, setPaying] = useState(false);

  async function run(fn) {
    setError('');
    setBusy(true);
    try {
      await fn();
      await onChanged();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  const setStatus = (status) => run(() => api(`/deliveries/${d.id}/status`, { method: 'POST', body: { status } }));

  return (
    <Card>
      <Text style={{ fontWeight: '600', fontSize: 16, color: colors.text }}>
        {d.pickup_address} → {d.dropoff_address}
      </Text>
      <Muted>
        {statusLabel[d.status]} · {d.distance_km} km · {money(d.price)}
        {d.transport_name ? ` · ${d.transport_name}` : ''}
        {d.i_am_requester && !d.paid && d.status !== 'cancelled' ? ' · Not paid' : ''}
      </Muted>
      {d.item_description ? <Muted>{d.item_description}</Muted> : null}

      {['accepted', 'picked_up'].includes(d.status) ? (
        <Button
          title={d.i_am_requester ? 'Track on map' : 'Open map and navigation'}
          onPress={() => navigation.navigate('Tracking', { deliveryId: d.id })}
        />
      ) : null}

      {d.other_user_id && ['accepted', 'picked_up', 'delivered'].includes(d.status) ? (
        <Row>
          <Button
            title={`Message ${d.i_am_requester ? 'courier' : 'customer'}`}
            kind="secondary"
            style={{ marginRight: 8 }}
            onPress={() => navigation.navigate('Chat', { userId: d.other_user_id, name: d.other_name })}
          />
          {d.other_phone && ['accepted', 'picked_up'].includes(d.status) ? (
            <Button title="Call" kind="secondary" onPress={() => Linking.openURL(`tel:${d.other_phone}`)} />
          ) : null}
        </Row>
      ) : null}

      {d.i_am_requester && !d.paid && d.status !== 'cancelled' ? (
        paying ? (
          <>
            <Field label="Mobile money number" value={msisdn} onChangeText={setMsisdn} keyboardType="phone-pad" />
            <Button
              title="Pay now"
              loading={busy}
              disabled={msisdn.length < 8}
              onPress={() =>
                run(async () => {
                  const r = await api(`/deliveries/${d.id}/pay`, { method: 'POST', body: { msisdn } });
                  if (r.paymentStatus !== 'succeeded') throw new Error('Payment did not go through');
                })
              }
            />
          </>
        ) : (
          <Button title="Pay with mobile money" onPress={() => setPaying(true)} />
        )
      ) : null}

      {!d.i_am_requester && d.status === 'accepted' ? <Button title="Mark as picked up" onPress={() => setStatus('picked_up')} loading={busy} /> : null}
      {!d.i_am_requester && d.status === 'picked_up' ? <Button title="Mark as delivered" onPress={() => setStatus('delivered')} loading={busy} /> : null}
      {d.i_am_requester && ['requested', 'accepted'].includes(d.status) ? (
        <Button title="Cancel delivery" kind="danger" onPress={() => setStatus('cancelled')} loading={busy} />
      ) : null}

      {d.i_am_requester && d.status === 'delivered' && !d.rated ? (
        rating ? (
          <View>
            <H2>Rate the service</H2>
            <Row>
              {[1, 2, 3, 4, 5].map((n) => (
                <Chip key={n} label={`${n} ★`} selected={stars === n} onPress={() => setStars(n)} />
              ))}
            </Row>
            <Field label="Comment (optional)" value={comment} onChangeText={setComment} autoCapitalize="sentences" />
            <Button
              title="Send rating"
              disabled={!stars}
              loading={busy}
              onPress={() =>
                run(() =>
                  api(`/deliveries/${d.id}/rating`, {
                    method: 'POST',
                    body: { stars, comment: comment || undefined },
                  })
                )
              }
            />
          </View>
        ) : (
          <Button title="Rate this delivery" kind="secondary" onPress={() => setRating(true)} />
        )
      ) : null}
      {d.i_am_requester && d.rated ? <Muted>You rated this delivery.</Muted> : null}
      <ErrorText>{error}</ErrorText>
    </Card>
  );
}

export function DeliveriesScreen() {
  const { items, error, refreshing, load } = useList('/deliveries/mine');
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.bg }}
      contentContainerStyle={{ padding: 20, paddingBottom: 40 }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={load} />}
    >
      <ErrorText>{error}</ErrorText>
      {items.length === 0 && !error ? <Muted>No deliveries yet. Pull down to refresh.</Muted> : null}
      {items.map((d) => (
        <DeliveryCard key={d.id} d={d} onChanged={load} />
      ))}
    </ScrollView>
  );
}

export function JobsScreen() {
  const { items, error, refreshing, load, setError } = useList('/deliveries/available');
  const [busyId, setBusyId] = useState(null);

  async function accept(id) {
    setBusyId(id);
    try {
      await api(`/deliveries/${id}/accept`, { method: 'POST', body: {} });
      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.bg }}
      contentContainerStyle={{ padding: 20, paddingBottom: 40 }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={load} />}
    >
      <Muted>Paid deliveries waiting for a courier. Individuals need the "Delivery service" profession on their profile; businesses need an active transport slot.</Muted>
      <ErrorText>{error}</ErrorText>
      {items.length === 0 && !error ? <Muted>Nothing available right now.</Muted> : null}
      {items.map((j) => (
        <Card key={j.id}>
          <Text style={{ fontWeight: '600', fontSize: 16, color: colors.text }}>
            {j.pickup_address} → {j.dropoff_address}
          </Text>
          <Muted>
            {j.distance_km} km · {money(j.price)}
            {j.transport_name ? ` · ${j.transport_name}` : ''}
          </Muted>
          {j.item_description ? <Muted>{j.item_description}</Muted> : null}
          <Button title="Accept delivery" onPress={() => accept(j.id)} loading={busyId === j.id} />
        </Card>
      ))}
    </ScrollView>
  );
}
