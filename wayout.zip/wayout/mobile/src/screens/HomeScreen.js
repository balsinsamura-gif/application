import React, { useCallback, useState } from 'react';
import { Text } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { Button, Card, ErrorText, Field, H1, H2, Muted, Screen } from '../ui';

export default function HomeScreen({ navigation }) {
  const { me } = useAuth();
  const [summary, setSummary] = useState(null);
  const [lookup, setLookup] = useState('');
  const [error, setError] = useState('');

  const isBiz = me.accountType === 'business';
  const name = isBiz ? me.profile?.company_name : me.profile?.full_name;

  useFocusEffect(
    useCallback(() => {
      if (isBiz) api('/business/summary').then(setSummary).catch(() => {});
    }, [isBiz])
  );

  function openProfile() {
    setError('');
    // Accepts a full link (wayout://p/abc123) or just the code
    const slug = lookup.trim().split('/').filter(Boolean).pop();
    if (!slug) return setError('Paste a profile link or code');
    navigation.navigate('PublicProfile', { slug });
  }

  return (
    <Screen>
      <H1>Hello, {name}</H1>
      <Muted>{isBiz ? 'Business account' : 'Personal account'}</Muted>

      {!me.emailVerified || !me.phoneVerified ? (
        <Card>
          <Text>Your account is not fully verified yet.</Text>
        </Card>
      ) : null}

      <Button title="New delivery" onPress={() => navigation.navigate('NewDelivery')} />
      <Button title="Find a professional" kind="secondary" onPress={() => navigation.navigate('Find')} />
      <Muted>Caregivers, chefs, tutors, housekeepers and delivery services.</Muted>

      {isBiz && summary ? (
        <Card>
          <H2>Overview</H2>
          <Text>Active slots: {summary.activeSlots}</Text>
          <Text>In progress: {summary.in_progress}</Text>
          <Text>Completed: {summary.completed}</Text>
          <Text>Requested by you: {summary.requested}</Text>
          <Text>
            Rating: {summary.rating.count ? `${summary.rating.average} ★ (${summary.rating.count})` : 'no ratings yet'}
          </Text>
        </Card>
      ) : null}

      <H2>View a profile</H2>
      <Muted>Paste a profile link or code someone shared with you.</Muted>
      <Field value={lookup} onChangeText={setLookup} placeholder="wayout://p/..." />
      <ErrorText>{error}</ErrorText>
      <Button title="Open profile" kind="secondary" onPress={openProfile} />
    </Screen>
  );
}
