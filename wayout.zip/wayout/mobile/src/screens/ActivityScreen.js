import React, { useState } from 'react';
import { View } from 'react-native';
import { useAuth } from '../lib/auth';
import { Chip, Row, colors } from '../ui';
import { DeliveriesScreen, JobsScreen } from './DeliveryScreens';
import { ServicesScreen } from './ServiceScreens';

// One place for everything in progress: my deliveries, service bookings, and open delivery jobs.
export default function ActivityScreen() {
  const { me } = useAuth();
  const [tab, setTab] = useState('deliveries');
  const canCarry =
    me.accountType === 'business' || (me.professions || []).some((p) => p.name === 'Delivery service');

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Row style={{ paddingHorizontal: 20, paddingTop: 14 }}>
        <Chip label="Deliveries" selected={tab === 'deliveries'} onPress={() => setTab('deliveries')} />
        <Chip label="Services" selected={tab === 'services'} onPress={() => setTab('services')} />
        {canCarry ? <Chip label="Open jobs" selected={tab === 'jobs'} onPress={() => setTab('jobs')} /> : null}
      </Row>
      {tab === 'deliveries' ? <DeliveriesScreen /> : null}
      {tab === 'services' ? <ServicesScreen /> : null}
      {tab === 'jobs' && canCarry ? <JobsScreen /> : null}
    </View>
  );
}
