import React, { useCallback, useEffect, useState } from 'react';
import { Linking, RefreshControl, ScrollView, Text, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { Button, Card, Chip, ErrorText, Field, H1, H2, Muted, Row, Screen, colors, money } from '../ui';

const unitLabel = (u) => (u === 'per_hour' ? 'per hour' : 'per visit');

// ---------- Find a professional ----------
export function FindScreen({ navigation }) {
  const [professions, setProfessions] = useState([]);
  const [professionId, setProfessionId] = useState(null);
  const [city, setCity] = useState('');
  const [search, setSearch] = useState('');
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api('/meta/professions').then(setProfessions).catch(() => {});
  }, []);

  async function run() {
    setError('');
    setBusy(true);
    try {
      const qs = new URLSearchParams();
      if (professionId) qs.set('professionId', String(professionId));
      if (city.trim()) qs.set('city', city.trim());
      if (search.trim()) qs.set('search', search.trim());
      setResults(await api(`/providers?${qs.toString()}`));
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  // Load the full list the first time
  useEffect(() => {
    run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Screen>
      <H1>Find a professional</H1>
      <Row>
        <Chip label="All" selected={professionId === null} onPress={() => setProfessionId(null)} />
        {professions.map((p) => (
          <Chip key={p.id} label={p.name} selected={professionId === p.id} onPress={() => setProfessionId(p.id)} />
        ))}
      </Row>
      <Field label="City" value={city} onChangeText={setCity} autoCapitalize="words" />
      <Field label="Name" value={search} onChangeText={setSearch} autoCapitalize="words" />
      <Button title="Search" onPress={run} loading={busy} />
      <ErrorText>{error}</ErrorText>

      {results && results.length === 0 ? <Muted>No professionals found. Try fewer filters.</Muted> : null}
      {(results || []).map((r) => (
        <Card key={`${r.userId}-${r.professionId}`}>
          <Text style={{ fontWeight: '700', fontSize: 16, color: colors.text }}>{r.name}</Text>
          <Muted>
            {r.professionName}
            {r.city ? ` · ${r.city}` : ''}
            {r.rate !== null ? ` · ${money(r.rate)} ${unitLabel(r.rateUnit)}` : ' · priced by distance'}
          </Muted>
          <Text style={{ marginBottom: 6 }}>
            {r.ratingCount ? `${r.ratingAverage} ★ (${r.ratingCount})` : 'No ratings yet'}
          </Text>
          {r.summary ? <Muted>{r.summary}</Muted> : null}
          <Button title="View profile" kind="secondary" onPress={() => navigation.navigate('PublicProfile', { slug: r.shareSlug })} />
        </Card>
      ))}
    </Screen>
  );
}

// ---------- Request a service ----------
// Date format typed by the person: 2026-11-02 14:30 (their local time)
function parseLocal(text) {
  const m = text.trim().match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})$/);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]));
  return Number.isNaN(d.getTime()) ? null : d;
}

export function ServiceRequestScreen({ route, navigation }) {
  const { providerId, providerName, professionId, professionName, rate, rateUnit } = route.params;
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [when, setWhen] = useState('');
  const [hours, setHours] = useState('1');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const h = parseFloat(hours);
  const price = rateUnit === 'per_hour' ? rate * (h || 0) : rate;

  async function submit() {
    setError('');
    const date = parseLocal(when);
    if (!date) return setError('Enter the date and time like 2026-11-02 14:30');
    if (!(h >= 0.5)) return setError('Enter at least 0.5 hours');
    setBusy(true);
    try {
      await api('/services', {
        method: 'POST',
        body: { providerId, professionId, description, address, scheduledAt: date.toISOString(), hours: h },
      });
      navigation.navigate('Main', { screen: 'Activity' });
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen>
      <H1>Request {professionName}</H1>
      <Muted>
        {providerName} · {money(rate)} {unitLabel(rateUnit)}
      </Muted>
      <Field label="What do you need?" value={description} onChangeText={setDescription} multiline autoCapitalize="sentences" />
      <Field label="Where (address)" value={address} onChangeText={setAddress} autoCapitalize="sentences" />
      <Field label="Date and time (YYYY-MM-DD HH:MM)" value={when} onChangeText={setWhen} placeholder="2026-11-02 14:30" />
      {rateUnit === 'per_hour' ? (
        <Field label="Hours" value={hours} onChangeText={setHours} keyboardType="decimal-pad" />
      ) : null}
      <Card>
        <Muted>Estimated price</Muted>
        <H1>{money(price)}</H1>
        <Muted>You pay by mobile money after the professional accepts your request.</Muted>
      </Card>
      <ErrorText>{error}</ErrorText>
      <Button title="Send request" onPress={submit} loading={busy} disabled={description.length < 3 || address.length < 3 || !when} />
    </Screen>
  );
}

// ---------- My service bookings ----------
function BookingCard({ s, onChanged }) {
  const navigation = useNavigation();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [msisdn, setMsisdn] = useState('');
  const [paying, setPaying] = useState(false);
  const [stars, setStars] = useState(0);
  const [comment, setComment] = useState('');
  const [rating, setRating] = useState(false);

  async function run(fn) {
    setError('');
    setBusy(true);
    try {
      await fn();
      await onChanged();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  const post = (path, body) => api(`/services/${s.id}/${path}`, { method: 'POST', body });
  const mine = s.i_am_customer;
  const statusText = { requested: 'Waiting for reply', accepted: 'Accepted', declined: 'Declined', completed: 'Completed', cancelled: 'Cancelled' }[s.status];

  return (
    <Card>
      <Text style={{ fontWeight: '700', fontSize: 16, color: colors.text }}>
        {s.profession_name} · {mine ? 'with' : 'for'} {s.other_name}
      </Text>
      <Muted>
        {statusText} · {new Date(s.scheduled_at).toLocaleString()} · {money(s.price)}
        {s.status === 'accepted' ? (s.paid ? ' · Paid' : ' · Not paid') : ''}
      </Muted>
      <Text style={{ marginBottom: 4 }}>{s.description}</Text>
      <Muted>{s.address}</Muted>

      <Row>
        <Button
          title="Message"
          kind="secondary"
          style={{ marginRight: 8 }}
          onPress={() => navigation.navigate('Chat', { userId: s.other_user_id, name: s.other_name })}
        />
        {s.other_phone ? <Button title="Call" kind="secondary" onPress={() => Linking.openURL(`tel:${s.other_phone}`)} /> : null}
      </Row>

      {!mine && s.status === 'requested' ? (
        <Row>
          <Button title="Accept" style={{ marginRight: 8 }} onPress={() => run(() => post('respond', { accept: true }))} loading={busy} />
          <Button title="Decline" kind="danger" onPress={() => run(() => post('respond', { accept: false }))} loading={busy} />
        </Row>
      ) : null}
      {!mine && s.status === 'accepted' && s.paid ? (
        <>
          <Button
            title="Navigate to the address"
            kind="secondary"
            onPress={() =>
              Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(s.address)}`)
            }
          />
          <Button title="Mark as completed" onPress={() => run(() => post('status', { status: 'completed' }))} loading={busy} />
        </>
      ) : null}
      {!mine && s.status === 'accepted' && !s.paid ? <Muted>Waiting for the customer to pay.</Muted> : null}

      {mine && s.status === 'accepted' && !s.paid ? (
        paying ? (
          <>
            <Field label="Mobile money number" value={msisdn} onChangeText={setMsisdn} keyboardType="phone-pad" />
            <Button
              title="Pay now"
              loading={busy}
              disabled={msisdn.length < 8}
              onPress={() =>
                run(async () => {
                  const r = await post('pay', { msisdn });
                  if (r.paymentStatus !== 'succeeded') throw new Error('Payment did not go through');
                })
              }
            />
          </>
        ) : (
          <Button title="Pay with mobile money" onPress={() => setPaying(true)} />
        )
      ) : null}
      {mine && ['requested', 'accepted'].includes(s.status) && !s.paid ? (
        <Button title="Cancel request" kind="danger" onPress={() => run(() => post('status', { status: 'cancelled' }))} loading={busy} />
      ) : null}

      {mine && s.status === 'completed' && !s.rated ? (
        rating ? (
          <View>
            <H2>Rate the service</H2>
            <Row>
              {[1, 2, 3, 4, 5].map((n) => (
                <Chip key={n} label={`${n} ★`} selected={stars === n} onPress={() => setStars(n)} />
              ))}
            </Row>
            <Field label="Comment (optional)" value={comment} onChangeText={setComment} autoCapitalize="sentences" />
            <Button
              title="Send rating"
              disabled={!stars}
              loading={busy}
              onPress={() => run(() => post('rating', { stars, comment: comment || undefined }))}
            />
          </View>
        ) : (
          <Button title="Rate this service" kind="secondary" onPress={() => setRating(true)} />
        )
      ) : null}
      {mine && s.rated ? <Muted>You rated this service.</Muted> : null}
      <ErrorText>{error}</ErrorText>
    </Card>
  );
}

export function ServicesScreen() {
  const { me } = useAuth();
  const navigation = useNavigation();
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    setRefreshing(true);
    try {
      setItems(await api('/services/mine'));
      setError('');
    } catch (e) {
      setError(e.message);
    } finally {
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.bg }}
      contentContainerStyle={{ padding: 20, paddingBottom: 40 }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={load} />}
    >
      <Button title="Find a professional" onPress={() => navigation.navigate('Find')} />
      <ErrorText>{error}</ErrorText>
      {items.length === 0 && !error ? (
        <Muted>
          No bookings yet.{me.professions?.length ? ' Requests sent to you will show up here.' : ''}
        </Muted>
      ) : null}
      {items.map((s) => (
        <BookingCard key={s.id} s={s} onChanged={load} />
      ))}
    </ScrollView>
  );
}
