import React, { useCallback, useEffect, useState } from 'react';
import { Share, Text } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { api } from '../lib/api';
import { Button, Card, Chip, ErrorText, Field, H1, H2, Muted, Row, Screen, money } from '../ui';

// Business-only area: transport slots and referrals
export default function BusinessScreen() {
  const [types, setTypes] = useState([]);
  const [slots, setSlots] = useState([]);
  const [ref, setRef] = useState(null);
  const [typeId, setTypeId] = useState(null);
  const [quantity, setQuantity] = useState('1');
  const [months, setMonths] = useState('1');
  const [msisdn, setMsisdn] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [s, r] = await Promise.all([api('/business/slots'), api('/business/referrals')]);
      setSlots(s);
      setRef(r);
    } catch (e) {
      setError(e.message);
    }
  }, []);

  useEffect(() => {
    api('/meta/transport-types').then(setTypes).catch(() => {});
  }, []);
  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const selected = types.find((t) => t.id === typeId);
  const total = selected ? Number(selected.slot_price) * (parseInt(quantity, 10) || 0) * (parseInt(months, 10) || 0) : 0;

  async function buy() {
    setError('');
    setBusy(true);
    try {
      await api('/business/slots', {
        method: 'POST',
        body: {
          transportTypeId: typeId,
          quantity: parseInt(quantity, 10),
          months: parseInt(months, 10),
          msisdn,
        },
      });
      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen>
      <H1>Business</H1>

      <H2>Buy transport slots</H2>
      <Muted>A slot lets your business carry one delivery at a time with that type of transport.</Muted>
      <Row>
        {types.map((t) => (
          <Chip key={t.id} label={`${t.name} · ${money(t.slot_price)}/mo`} selected={typeId === t.id} onPress={() => setTypeId(t.id)} />
        ))}
      </Row>
      <Field label="Number of slots" value={quantity} onChangeText={setQuantity} keyboardType="number-pad" />
      <Field label="Months" value={months} onChangeText={setMonths} keyboardType="number-pad" />
      <Field label="Mobile money number" value={msisdn} onChangeText={setMsisdn} keyboardType="phone-pad" />
      {selected ? <Muted>Total: {money(total)}</Muted> : null}
      <ErrorText>{error}</ErrorText>
      <Button title="Pay and activate slots" onPress={buy} loading={busy} disabled={!selected || total <= 0 || msisdn.length < 8} />

      <H2>My slots</H2>
      {slots.length === 0 ? <Muted>No slots yet.</Muted> : null}
      {slots.map((s) => (
        <Card key={s.id}>
          <Text style={{ fontWeight: '600' }}>
            {s.quantity} × {s.transport_name}
          </Text>
          <Muted>
            {s.active ? 'Active' : 'Expired'} until {new Date(s.expires_at).toLocaleDateString()} · paid {money(s.total_paid)}
          </Muted>
        </Card>
      ))}

      <H2>Referrals</H2>
      {ref ? (
        <Card>
          <Muted>Share your code with other businesses and organizations. You earn {ref.rewardPercent}% of their first slot purchase.</Muted>
          <H1>{ref.referralCode}</H1>
          <Button
            title="Share my referral code"
            kind="secondary"
            onPress={() =>
              Share.share({ message: `Join me on Way Out as a business. Use my referral code ${ref.referralCode} when you sign up.` })
            }
          />
          <Muted>Total rewards: {money(ref.totalRewards)}</Muted>
          {ref.referred.map((r) => (
            <Text key={r.id} style={{ marginTop: 6 }}>
              {r.company_name} {r.reward ? `· reward ${money(r.reward)}` : '· no purchase yet'}
            </Text>
          ))}
        </Card>
      ) : null}
    </Screen>
  );
}
