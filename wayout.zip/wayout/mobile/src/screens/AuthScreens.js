import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { Button, Card, Chip, ErrorText, Field, H1, H2, Muted, Row, Screen } from '../ui';
import { ProfessionPicker, professionsPayload } from '../components/ProfessionPicker';

export function WelcomeScreen({ navigation }) {
  return (
    <Screen>
      <View style={{ marginTop: 40 }}>
        <H1>Welcome</H1>
        <Muted>Send and receive deliveries, or run your business deliveries from one app.</Muted>
      </View>
      <Card>
        <H2>I am a person</H2>
        <Muted>Send and receive packages, book professionals, or offer your own services like delivery, caregiving, cooking, tutoring or housekeeping.</Muted>
        <Button title="Create personal account" onPress={() => navigation.navigate('Register', { type: 'individual' })} />
      </Card>
      <Card>
        <H2>I am a business or organization</H2>
        <Muted>Company account with transport slots, referral link and a company profile.</Muted>
        <Button title="Create business account" onPress={() => navigation.navigate('Register', { type: 'business' })} />
      </Card>
      <Button title="I already have an account" kind="secondary" onPress={() => navigation.navigate('Login')} />
    </Screen>
  );
}

export function RegisterScreen({ route, navigation }) {
  const type = route.params.type;
  const isBiz = type === 'business';
  const [f, setF] = useState({});
  const [categories, setCategories] = useState([]);
  const [picked, setPicked] = useState([]);
  const [professions, setProfessions] = useState([]);
  const [offered, setOffered] = useState([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (k) => (v) => setF((p) => ({ ...p, [k]: v }));

  useEffect(() => {
    api(`/meta/categories?type=${type}`).then(setCategories).catch(() => {});
    api('/meta/professions').then(setProfessions).catch(() => {});
  }, [type]);

  const toggle = (id) => setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  async function submit() {
    setError('');
    const prof = professionsPayload(offered, professions);
    if (prof.error) return setError(prof.error);
    setBusy(true);
    try {
      const body = {
        professions: prof.items,
        email: f.email,
        phone: f.phone,
        password: f.password,
        address: f.address || undefined,
        city: f.city || undefined,
        categoryIds: picked,
        ...(isBiz
          ? {
              companyName: f.companyName,
              registrationNo: f.registrationNo || undefined,
              contactPerson: f.contactPerson || undefined,
              description: f.description || undefined,
              referralCode: f.referralCode || undefined,
            }
          : { fullName: f.fullName }),
      };
      const res = await api(`/auth/register/${type}`, { method: 'POST', body });
      navigation.replace('Verify', { challengeToken: res.challengeToken });
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen>
      <H1>{isBiz ? 'Business account' : 'Personal account'}</H1>
      {isBiz ? (
        <>
          <Field label="Company or organization name" value={f.companyName} onChangeText={set('companyName')} autoCapitalize="words" />
          <Field label="Registration number (optional)" value={f.registrationNo} onChangeText={set('registrationNo')} />
          <Field label="Contact person" value={f.contactPerson} onChangeText={set('contactPerson')} autoCapitalize="words" />
        </>
      ) : (
        <Field label="Full name" value={f.fullName} onChangeText={set('fullName')} autoCapitalize="words" />
      )}
      <Field label="Email" value={f.email} onChangeText={set('email')} keyboardType="email-address" />
      <Field label="Phone number" value={f.phone} onChangeText={set('phone')} keyboardType="phone-pad" placeholder="+23276000000" />
      <Field label="Password (8+ characters)" value={f.password} onChangeText={set('password')} secureTextEntry />
      <Field label="Address" value={f.address} onChangeText={set('address')} autoCapitalize="sentences" />
      <Field label="City" value={f.city} onChangeText={set('city')} autoCapitalize="words" />
      {isBiz ? (
        <>
          <Field label="About the business (optional)" value={f.description} onChangeText={set('description')} multiline autoCapitalize="sentences" />
          <Field label="Referral code (optional)" value={f.referralCode} onChangeText={set('referralCode')} autoCapitalize="characters" />
        </>
      ) : null}

      <H2>{isBiz ? 'Services you offer' : 'Work you offer (optional)'}</H2>
      <Muted>
        Pick what you do so customers can find and book you. Choose "Delivery service" to carry deliveries. Skip this if you only
        want to order services.
      </Muted>
      <ProfessionPicker professions={professions} value={offered} onChange={setOffered} />

      {categories.length ? <H2>Profile categories</H2> : null}
      <Row>
        {categories.map((c) => (
          <Chip key={c.id} label={c.name} selected={picked.includes(c.id)} onPress={() => toggle(c.id)} />
        ))}
      </Row>

      <ErrorText>{error}</ErrorText>
      <Button title="Create account" onPress={submit} loading={busy} />
    </Screen>
  );
}

// Enter the email code and the phone code. Both are needed before the account can be used.
export function VerifyScreen({ route }) {
  const { signIn } = useAuth();
  const [challengeToken, setChallengeToken] = useState(route.params.challengeToken);
  const [emailCode, setEmailCode] = useState('');
  const [phoneCode, setPhoneCode] = useState('');
  const [done, setDone] = useState({ email: !!route.params.emailVerified, phone: !!route.params.phoneVerified });
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);

  async function verify(channel) {
    setError('');
    setBusy(true);
    try {
      const code = channel === 'email' ? emailCode : phoneCode;
      const res = await api('/auth/verify', { method: 'POST', body: { challengeToken, channel, code } });
      setDone({ email: res.emailVerified, phone: res.phoneVerified });
      if (res.accessToken) await signIn(res.accessToken);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function resend(channel) {
    setError('');
    setInfo('');
    try {
      await api('/auth/resend', { method: 'POST', body: { challengeToken, channel } });
      setInfo('A new code was sent.');
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <Screen>
      <H1>Verify your account</H1>
      <Muted>Enter the 6-digit code from your email and the 6-digit code sent to your phone.</Muted>

      <Card>
        <H2>Email code {done.email ? '✓' : ''}</H2>
        {!done.email ? (
          <>
            <Field value={emailCode} onChangeText={setEmailCode} keyboardType="number-pad" maxLength={6} placeholder="123456" />
            <Button title="Verify email" onPress={() => verify('email')} loading={busy} disabled={emailCode.length !== 6} />
            <Button title="Send a new email code" kind="secondary" onPress={() => resend('email')} />
          </>
        ) : null}
      </Card>

      <Card>
        <H2>Phone code {done.phone ? '✓' : ''}</H2>
        {!done.phone ? (
          <>
            <Field value={phoneCode} onChangeText={setPhoneCode} keyboardType="number-pad" maxLength={6} placeholder="123456" />
            <Button title="Verify phone" onPress={() => verify('phone')} loading={busy} disabled={phoneCode.length !== 6} />
            <Button title="Send a new SMS code" kind="secondary" onPress={() => resend('phone')} />
          </>
        ) : null}
      </Card>

      <ErrorText>{error}</ErrorText>
      {info ? <Muted>{info}</Muted> : null}
    </Screen>
  );
}

export function LoginScreen({ navigation }) {
  const { signIn, hasDeviceToken, biometricLogin } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit() {
    setError('');
    setBusy(true);
    try {
      const res = await api('/auth/login', { method: 'POST', body: { email, password } });
      if (res.status === 'ok') await signIn(res.accessToken);
      else if (res.status === '2fa_required') navigation.navigate('TwoFactor', { challengeToken: res.challengeToken });
      else if (res.status === 'verification_required') {
        navigation.navigate('Verify', {
          challengeToken: res.challengeToken,
          emailVerified: res.emailVerified,
          phoneVerified: res.phoneVerified,
        });
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function fingerprint() {
    setError('');
    try {
      await biometricLogin();
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <Screen>
      <H1>Log in</H1>
      {hasDeviceToken ? <Button title="Log in with fingerprint" onPress={fingerprint} /> : null}
      <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" />
      <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
      <ErrorText>{error}</ErrorText>
      <Button title="Log in" onPress={submit} loading={busy} kind={hasDeviceToken ? 'secondary' : 'primary'} />
    </Screen>
  );
}

export function TwoFactorScreen({ route }) {
  const { signIn } = useAuth();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit() {
    setError('');
    setBusy(true);
    try {
      const res = await api('/auth/login/2fa', {
        method: 'POST',
        body: { challengeToken: route.params.challengeToken, code },
      });
      await signIn(res.accessToken);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen>
      <H1>Two-factor code</H1>
      <Muted>Open your authenticator app and enter the 6-digit code.</Muted>
      <Field value={code} onChangeText={setCode} keyboardType="number-pad" maxLength={6} placeholder="123456" />
      <ErrorText>{error}</ErrorText>
      <Button title="Confirm" onPress={submit} loading={busy} disabled={code.length !== 6} />
    </Screen>
  );
}
