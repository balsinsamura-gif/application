import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Linking, Text, View } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { useFocusEffect } from '@react-navigation/native';
import { api } from '../lib/api';
import { Button, ErrorText, Muted, colors } from '../ui';

const POLL_MS = 5000;

const statusText = {
  requested: 'Waiting for a courier',
  accepted: 'Courier is heading to the pickup',
  picked_up: 'Package picked up, on the way',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
};

// Live map for one delivery.
// Customer: sees the courier moving. Courier: shares their position and can open turn-by-turn navigation.
export default function TrackingScreen({ route }) {
  const { deliveryId } = route.params;
  const [t, setT] = useState(null);
  const [error, setError] = useState('');
  const map = useRef(null);
  const watcher = useRef(null);

  const load = useCallback(async () => {
    try {
      setT(await api(`/deliveries/${deliveryId}/tracking`));
      setError('');
    } catch (e) {
      setError(e.message);
    }
  }, [deliveryId]);

  useFocusEffect(
    useCallback(() => {
      load();
      const timer = setInterval(load, POLL_MS);
      return () => clearInterval(timer);
    }, [load])
  );

  const active = t && ['accepted', 'picked_up'].includes(t.status);
  const iAmCourier = t?.iAmCourier;

  // Courier phone: send position while this screen is open and the delivery is active
  useEffect(() => {
    if (!active || !iAmCourier) return undefined;
    let cancelled = false;
    (async () => {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (perm.status !== 'granted') {
        setError('Allow location access so the customer can follow your delivery.');
        return;
      }
      const sub = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, timeInterval: 8000, distanceInterval: 20 },
        (pos) => {
          api(`/deliveries/${deliveryId}/location`, {
            method: 'POST',
            body: { lat: pos.coords.latitude, lng: pos.coords.longitude },
          }).catch(() => {});
        }
      );
      if (cancelled) sub.remove();
      else watcher.current = sub;
    })();
    return () => {
      cancelled = true;
      watcher.current?.remove();
      watcher.current = null;
    };
  }, [active, iAmCourier, deliveryId]);

  // Fit the map to everything we know about
  useEffect(() => {
    if (!t || !map.current) return;
    const pts = [t.pickup, t.dropoff, t.courier].filter(Boolean).map((p) => ({ latitude: p.lat, longitude: p.lng }));
    map.current.fitToCoordinates(pts, {
      edgePadding: { top: 80, right: 60, bottom: 220, left: 60 },
      animated: true,
    });
  }, [t?.courier?.lat, t?.courier?.lng, t?.status, !!t]);

  if (!t) {
    return (
      <View style={{ flex: 1, padding: 20 }}>
        {error ? <ErrorText>{error}</ErrorText> : <Muted>Loading map…</Muted>}
      </View>
    );
  }

  // Where the courier should head next
  const target = t.status === 'accepted' ? t.pickup : t.dropoff;
  const navigate = () =>
    Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${target.lat}%2C${target.lng}&travelmode=driving`);

  const ageSeconds = t.courier ? Math.round((Date.now() - new Date(t.courier.updatedAt).getTime()) / 1000) : null;

  return (
    <View style={{ flex: 1 }}>
      <MapView
        ref={map}
        style={{ flex: 1 }}
        showsUserLocation={iAmCourier}
        initialRegion={{
          latitude: t.pickup.lat,
          longitude: t.pickup.lng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        }}
      >
        <Marker coordinate={{ latitude: t.pickup.lat, longitude: t.pickup.lng }} title="Pickup" description={t.pickup.address} pinColor="green" />
        <Marker coordinate={{ latitude: t.dropoff.lat, longitude: t.dropoff.lng }} title="Drop-off" description={t.dropoff.address} pinColor="red" />
        {t.courier ? (
          <Marker coordinate={{ latitude: t.courier.lat, longitude: t.courier.lng }} title="Courier" pinColor="blue" />
        ) : null}
      </MapView>

      <View
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: '#fff',
          padding: 16,
          borderTopLeftRadius: 16,
          borderTopRightRadius: 16,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        <Text style={{ fontWeight: '700', fontSize: 17, color: colors.text }}>{statusText[t.status]}</Text>
        {!iAmCourier && active ? (
          <Muted>
            {t.courier
              ? `Courier position updated ${ageSeconds < 60 ? `${ageSeconds}s` : `${Math.round(ageSeconds / 60)} min`} ago`
              : 'Waiting for the courier to share their position'}
          </Muted>
        ) : null}
        {iAmCourier && active ? (
          <>
            <Muted>Your position is shared while this screen is open. Next stop: {t.status === 'accepted' ? 'pickup' : 'drop-off'}.</Muted>
            <Button title="Open navigation" onPress={navigate} />
          </>
        ) : null}
        <ErrorText>{error}</ErrorText>
      </View>
    </View>
  );
}
