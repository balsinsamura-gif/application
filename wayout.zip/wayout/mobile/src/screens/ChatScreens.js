import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  Linking,
  Platform,
  Pressable,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { api } from '../lib/api';
import { Muted, colors } from '../ui';

const POLL_MS = 4000;

// Chat with one person. New messages arrive by polling every few seconds.
export function ChatScreen({ route, navigation }) {
  const { userId, name } = route.params;
  const [messages, setMessages] = useState([]);
  const [phone, setPhone] = useState(null);
  const [text, setText] = useState('');
  const [error, setError] = useState('');
  const [sending, setSending] = useState(false);
  const lastId = useRef(0);
  const list = useRef(null);

  const load = useCallback(async () => {
    try {
      const data = await api(`/messages/with/${userId}?after=${lastId.current}`);
      setPhone(data.person.phone);
      if (data.messages.length) {
        lastId.current = data.messages[data.messages.length - 1].id;
        setMessages((prev) => [...prev, ...data.messages]);
      }
      setError('');
    } catch (e) {
      setError(e.message);
    }
  }, [userId]);

  // Poll only while this screen is on top
  useFocusEffect(
    useCallback(() => {
      load();
      const timer = setInterval(load, POLL_MS);
      return () => clearInterval(timer);
    }, [load])
  );

  useEffect(() => {
    navigation.setOptions({
      title: name || 'Chat',
      headerRight: () =>
        phone ? (
          <Pressable onPress={() => Linking.openURL(`tel:${phone}`)} hitSlop={10}>
            <Text style={{ color: colors.primary, fontWeight: '600', fontSize: 16 }}>Call</Text>
          </Pressable>
        ) : null,
    });
  }, [navigation, name, phone]);

  async function send() {
    const body = text.trim();
    if (!body) return;
    setSending(true);
    try {
      const m = await api(`/messages/with/${userId}`, { method: 'POST', body: { body } });
      lastId.current = Math.max(lastId.current, m.id);
      setMessages((prev) => [...prev, m]);
      setText('');
      setError('');
    } catch (e) {
      setError(e.message);
    } finally {
      setSending(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={90}
    >
      <FlatList
        ref={list}
        data={messages}
        keyExtractor={(m) => String(m.id)}
        contentContainerStyle={{ padding: 16 }}
        onContentSizeChange={() => list.current?.scrollToEnd({ animated: true })}
        ListEmptyComponent={<Muted>No messages yet. Say hello.</Muted>}
        renderItem={({ item }) => (
          <View
            style={{
              alignSelf: item.mine ? 'flex-end' : 'flex-start',
              backgroundColor: item.mine ? colors.primary : '#fff',
              borderWidth: item.mine ? 0 : 1,
              borderColor: colors.border,
              borderRadius: 14,
              paddingHorizontal: 12,
              paddingVertical: 8,
              marginBottom: 8,
              maxWidth: '80%',
            }}
          >
            <Text style={{ color: item.mine ? '#fff' : colors.text, fontSize: 16 }}>{item.body}</Text>
            <Text style={{ color: item.mine ? '#CCE9E5' : colors.muted, fontSize: 11, marginTop: 2 }}>
              {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </Text>
          </View>
        )}
      />
      {error ? <Text style={{ color: colors.danger, paddingHorizontal: 16 }}>{error}</Text> : null}
      <View style={{ flexDirection: 'row', padding: 10, borderTopWidth: 1, borderColor: colors.border, backgroundColor: '#fff' }}>
        <TextInput
          value={text}
          onChangeText={setText}
          placeholder="Write a message"
          placeholderTextColor="#9CA3AF"
          multiline
          maxLength={2000}
          style={{
            flex: 1,
            borderWidth: 1,
            borderColor: colors.border,
            borderRadius: 18,
            paddingHorizontal: 14,
            paddingVertical: 8,
            fontSize: 16,
            maxHeight: 110,
            color: colors.text,
          }}
        />
        <Pressable
          onPress={send}
          disabled={sending || !text.trim()}
          style={{
            marginLeft: 8,
            alignSelf: 'flex-end',
            backgroundColor: colors.primary,
            opacity: sending || !text.trim() ? 0.5 : 1,
            borderRadius: 18,
            paddingHorizontal: 16,
            paddingVertical: 10,
          }}
        >
          <Text style={{ color: '#fff', fontWeight: '600' }}>Send</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

// Inbox
export function ConversationsScreen({ navigation }) {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');

  useFocusEffect(
    useCallback(() => {
      let active = true;
      const load = () =>
        api('/messages/conversations')
          .then((d) => active && (setItems(d), setError('')))
          .catch((e) => active && setError(e.message));
      load();
      const timer = setInterval(load, 8000);
      return () => {
        active = false;
        clearInterval(timer);
      };
    }, [])
  );

  return (
    <FlatList
      style={{ flex: 1, backgroundColor: colors.bg }}
      contentContainerStyle={{ padding: 16 }}
      data={items}
      keyExtractor={(c) => c.userId}
      ListHeaderComponent={error ? <Text style={{ color: colors.danger, marginBottom: 8 }}>{error}</Text> : null}
      ListEmptyComponent={!error ? <Muted>No conversations yet. Open a profile or a delivery and tap Message.</Muted> : null}
      renderItem={({ item }) => (
        <Pressable
          onPress={() => navigation.navigate('Chat', { userId: item.userId, name: item.name })}
          style={{
            backgroundColor: '#fff',
            borderRadius: 12,
            borderWidth: 1,
            borderColor: colors.border,
            padding: 14,
            marginBottom: 10,
          }}
        >
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ fontWeight: '600', fontSize: 16, color: colors.text }}>{item.name}</Text>
            {item.unread > 0 ? (
              <View style={{ backgroundColor: colors.primary, borderRadius: 10, minWidth: 20, paddingHorizontal: 6, alignItems: 'center' }}>
                <Text style={{ color: '#fff', fontSize: 12 }}>{item.unread}</Text>
              </View>
            ) : null}
          </View>
          <Text numberOfLines={1} style={{ color: colors.muted, marginTop: 4 }}>
            {item.lastFromMe ? 'You: ' : ''}
            {item.lastMessage}
          </Text>
        </Pressable>
      )}
    />
  );
}
