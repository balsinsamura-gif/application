import React, { useEffect, useState } from 'react';
import { Image, Linking, Share, Switch, Text, View } from 'react-native';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { Button, Card, Chip, ErrorText, Field, H1, H2, Muted, Row, Screen } from '../ui';
import { ProfessionPicker, pickerFromMe, professionsPayload } from '../components/ProfessionPicker';

export function PublicProfileScreen({ route, navigation }) {
  const { me } = useAuth();
  const [p, setP] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api(`/profiles/${route.params.slug}`).then(setP).catch((e) => setError(e.message));
  }, [route.params.slug]);

  if (error) {
    return (
      <Screen>
        <ErrorText>{error}</ErrorText>
      </Screen>
    );
  }
  if (!p) return <Screen><Muted>Loading…</Muted></Screen>;

  return (
    <Screen>
      <H1>{p.name}</H1>
      <Muted>
        {p.accountType === 'business' ? 'Business / organization' : 'Personal account'}
        {p.city ? ` · ${p.city}` : ''}
      </Muted>
      <Text style={{ fontSize: 18, marginBottom: 8 }}>
        {p.rating.count ? `${p.rating.average} ★ from ${p.rating.count} ratings` : 'No ratings yet'}
      </Text>
      {p.description ? <Text style={{ marginBottom: 12 }}>{p.description}</Text> : null}
      <Row>
        {p.categories.map((c) => (
          <Chip key={c.id} label={c.name} selected onPress={() => {}} />
        ))}
      </Row>

      {p.userId !== me.id ? (
        <Row style={{ marginTop: 8 }}>
          <Button title="Message" style={{ marginRight: 8 }} onPress={() => navigation.navigate('Chat', { userId: p.userId, name: p.name })} />
          {p.callEnabled && p.phone ? <Button title="Call" kind="secondary" onPress={() => Linking.openURL(`tel:${p.phone}`)} /> : null}
        </Row>
      ) : null}

      {p.professions.length ? <H2>Services</H2> : null}
      {p.professions.map((s) => (
        <Card key={s.professionId}>
          <Text style={{ fontWeight: '600', fontSize: 16 }}>{s.name}</Text>
          <Muted>
            {s.usesRate ? `${s.rate} ${s.rateUnit === 'per_hour' ? 'per hour' : 'per visit'}` : 'Priced by distance for each delivery'}
          </Muted>
          {s.summary ? <Text style={{ marginBottom: 6 }}>{s.summary}</Text> : null}
          {s.usesRate && p.userId !== me.id ? (
            <Button
              title={`Request ${s.name}`}
              kind="secondary"
              onPress={() =>
                navigation.navigate('ServiceRequest', {
                  providerId: p.userId,
                  providerName: p.name,
                  professionId: s.professionId,
                  professionName: s.name,
                  rate: s.rate,
                  rateUnit: s.rateUnit,
                })
              }
            />
          ) : null}
        </Card>
      ))}

      <H2>Reviews</H2>
      {p.reviews.length === 0 ? <Muted>No reviews yet.</Muted> : null}
      {p.reviews.map((r, i) => (
        <Card key={i}>
          <Text>{'★'.repeat(r.stars)}{'☆'.repeat(5 - r.stars)}</Text>
          {r.comment ? <Text style={{ marginTop: 4 }}>{r.comment}</Text> : null}
        </Card>
      ))}
    </Screen>
  );
}

export function AccountScreen() {
  const { me, loadMe, signOut, enableBiometric, disableBiometric, hasDeviceToken } = useAuth();
  const isBiz = me.accountType === 'business';
  const [categories, setCategories] = useState([]);
  const [picked, setPicked] = useState(me.categories.map((c) => c.id));
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const [setup, setSetup] = useState(null);
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [disabling, setDisabling] = useState(false);
  const [professions, setProfessions] = useState([]);
  const [offered, setOffered] = useState(pickerFromMe(me.professions));

  useEffect(() => {
    api(`/meta/categories?type=${me.accountType}`).then(setCategories).catch(() => {});
    api('/meta/professions').then(setProfessions).catch(() => {});
  }, [me.accountType]);

  function saveProfessions() {
    const prof = professionsPayload(offered, professions);
    if (prof.error) {
      setMsg('');
      setError(prof.error);
      return;
    }
    run(() => api('/me/professions', { method: 'PUT', body: { professions: prof.items } }), 'Services saved');
  }

  async function run(fn, done) {
    setError('');
    setMsg('');
    try {
      await fn();
      await loadMe();
      if (done) setMsg(done);
    } catch (e) {
      setError(e.message);
    }
  }

  const toggleCat = (id) => setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  const link = `wayout://p/${me.shareSlug}`;

  return (
    <Screen>
      <H1>Account</H1>
      <Muted>
        {me.email} · {me.phone}
      </Muted>
      {msg ? <Text style={{ color: '#047857', marginBottom: 8 }}>{msg}</Text> : null}
      <ErrorText>{error}</ErrorText>

      <Card>
        <H2>My profile link</H2>
        <Muted>Anyone with this link can view your public profile and ratings.</Muted>
        <Text selectable style={{ marginBottom: 8 }}>{link}</Text>
        <Button title="Share my profile" kind="secondary" onPress={() => Share.share({ message: link })} />
      </Card>

      <Card>
        <H2>{isBiz ? 'Services we offer' : 'Work I offer'}</H2>
        <Muted>Customers can find and book you for these. Add "Delivery service" to carry deliveries.</Muted>
        <ProfessionPicker professions={professions} value={offered} onChange={setOffered} />
        <Button title="Save services" onPress={saveProfessions} />
      </Card>

      <Card>
        <H2>Profile categories</H2>
        <Row>
          {categories.map((c) => (
            <Chip key={c.id} label={c.name} selected={picked.includes(c.id)} onPress={() => toggleCat(c.id)} />
          ))}
        </Row>
        <Button
          title="Save categories"
          onPress={() => run(() => api('/me', { method: 'PUT', body: { categoryIds: picked } }), 'Categories saved')}
        />
      </Card>

      <Card>
        <Row style={{ justifyContent: 'space-between' }}>
          <View style={{ flex: 1, paddingRight: 12 }}>
            <H2>Allow calls</H2>
            <Muted>Show a Call button on your profile and during deliveries.</Muted>
          </View>
          <Switch
            value={me.callEnabled}
            onValueChange={(v) => run(() => api('/me', { method: 'PUT', body: { callEnabled: v } }))}
          />
        </Row>
      </Card>

      <Card>
        <H2>Two-factor authentication</H2>
        {me.twoFactorEnabled ? (
          disabling ? (
            <>
              <Field label="Enter your password to turn it off" value={password} onChangeText={setPassword} secureTextEntry />
              <Button
                title="Turn off 2FA"
                kind="danger"
                onPress={() =>
                  run(async () => {
                    await api('/auth/2fa/disable', { method: 'POST', body: { password } });
                    setDisabling(false);
                    setPassword('');
                  }, '2FA turned off')
                }
              />
            </>
          ) : (
            <>
              <Muted>On. You will enter an authenticator code when you log in.</Muted>
              <Button title="Turn off" kind="secondary" onPress={() => setDisabling(true)} />
            </>
          )
        ) : setup ? (
          <>
            <Muted>Scan this code with an authenticator app, or enter the key by hand.</Muted>
            <Image source={{ uri: setup.qrDataUrl }} style={{ width: 200, height: 200, alignSelf: 'center' }} />
            <Text selectable style={{ textAlign: 'center', marginVertical: 8 }}>{setup.secret}</Text>
            <Field label="6-digit code from the app" value={code} onChangeText={setCode} keyboardType="number-pad" maxLength={6} />
            <Button
              title="Turn on 2FA"
              disabled={code.length !== 6}
              onPress={() =>
                run(async () => {
                  await api('/auth/2fa/enable', { method: 'POST', body: { code } });
                  setSetup(null);
                  setCode('');
                }, '2FA is on')
              }
            />
          </>
        ) : (
          <>
            <Muted>Add a second step when logging in.</Muted>
            <Button title="Set up 2FA" onPress={() => run(async () => setSetup(await api('/auth/2fa/setup', { method: 'POST', body: {} })))} />
          </>
        )}
      </Card>

      <Card>
        <H2>Fingerprint login</H2>
        {me.biometricEnabled && hasDeviceToken ? (
          <>
            <Muted>On for this phone.</Muted>
            <Button title="Turn off" kind="secondary" onPress={() => run(disableBiometric, 'Fingerprint login turned off')} />
          </>
        ) : (
          <>
            <Muted>Log in with your fingerprint instead of typing your password.</Muted>
            <Button title="Turn on fingerprint login" onPress={() => run(enableBiometric, 'Fingerprint login is on')} />
          </>
        )}
      </Card>

      <Button title="Log out" kind="secondary" onPress={signOut} />
    </Screen>
  );
}
