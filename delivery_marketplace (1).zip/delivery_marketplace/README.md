# Delivery Marketplace App

Flutter + Firebase starter for a global delivery marketplace.

## Features included

- Personal and Business / Organization accounts
- Email signup + verification
- Phone OTP verification
- Biometric authentication support
- Distance-based pricing (bike / car / van / truck)
- Create delivery requests
- Profile viewing + call button
- Customer ratings
- Business transport slots (placeholder for payments)
- Referral codes for business accounts

## Setup instructions

### 1. Prerequisites
- Flutter SDK (3.0+)
- A Firebase project (https://console.firebase.google.com)
- Android Studio / Xcode for device builds

### 2. Configure Firebase
```bash
# Install FlutterFire CLI if needed
dart pub global activate flutterfire_cli

# From the project root
flutterfire configure
```
This replaces `lib/firebase_options.dart` with real values.

### 3. Enable Firebase services
In the Firebase Console:
- Authentication → Email/Password + Phone
- Firestore Database → create database
- (Optional) Storage

### 4. Run the app
```bash
flutter pub get
flutter run
```

### 5. Recommended next steps
- Add Google Maps / Distance Matrix for real road distance
- Integrate Stripe (or local payment providers) for payments
- Add deep links for profile sharing
- Implement Firebase Multi-Factor Authentication
- Add push notifications

## Project structure

```
lib/
├── main.dart
├── firebase_options.dart
├── core/
│   ├── models/
│   └── services/
└── features/
    ├── auth/
    ├── home/
    ├── delivery/
    ├── profiles/
    ├── ratings/
    └── slots/
```

## Notes
- Distance is currently a slider (placeholder). Replace with Google Distance Matrix or Mapbox.
- Payments and slot purchasing are stubs — connect a payment provider when ready.
- Keep API keys and secrets out of version control.
