class PricingService {
  static const double baseFare = 5.0;
  static const double ratePerKm = 1.5;
  static const double minFare = 8.0;

  /// Calculate price based on distance and vehicle type
  static double calculatePrice(double distanceKm, {String vehicleType = 'bike'}) {
    final multipliers = {
      'bike': 1.0,
      'car': 1.4,
      'van': 1.8,
      'truck': 2.5,
    };
    final multiplier = multipliers[vehicleType] ?? 1.0;
    final price = (baseFare + (distanceKm * ratePerKm)) * multiplier;
    return price < minFare ? minFare : double.parse(price.toStringAsFixed(2));
  }
}
