import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();
  User? get currentUser => _auth.currentUser;

  // ---------- SIGN UP (Email + Account Type) ----------
  Future<UserModel?> signUpWithEmail({
    required String email,
    required String password,
    required String name,
    required String accountType, // 'personal' or 'business'
    String? category,
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      await credential.user?.sendEmailVerification();

      final referralCode = accountType == 'business'
          ? 'REF${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}'
          : null;

      final user = UserModel(
        uid: credential.user!.uid,
        email: email.trim(),
        name: name.trim(),
        accountType: accountType,
        category: category,
        referralCode: referralCode,
        emailVerified: false,
      );

      await _firestore.collection('users').doc(user.uid).set(user.toMap());
      return user;
    } on FirebaseAuthException catch (e) {
      throw _mapAuthError(e);
    }
  }

  // ---------- SIGN IN ----------
  Future<UserModel?> signInWithEmail(String email, String password) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final doc =
          await _firestore.collection('users').doc(credential.user!.uid).get();
      if (!doc.exists) {
        throw Exception('User profile not found.');
      }
      return UserModel.fromMap(doc.data()!);
    } on FirebaseAuthException catch (e) {
      throw _mapAuthError(e);
    }
  }

  // ---------- PHONE OTP ----------
  String? _verificationId;

  Future<void> sendPhoneOTP(String phoneNumber) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber.trim(),
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (FirebaseAuthException e) {
        throw _mapAuthError(e);
      },
      codeSent: (String verificationId, int? resendToken) {
        _verificationId = verificationId;
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        _verificationId = verificationId;
      },
    );
  }

  Future<void> verifyPhoneOTP(String smsCode) async {
    if (_verificationId == null) {
      throw Exception('No verification ID. Request a new code.');
    }
    final credential = PhoneAuthProvider.credential(
      verificationId: _verificationId!,
      smsCode: smsCode.trim(),
    );
    final result = await _auth.signInWithCredential(credential);

    await _firestore.collection('users').doc(result.user!.uid).update({
      'phone': result.user!.phoneNumber,
      'phoneVerified': true,
    });
  }

  // ---------- PASSWORD RESET ----------
  Future<void> sendPasswordReset(String email) async {
    await _auth.sendPasswordResetEmail(email: email.trim());
  }

  Future<void> signOut() async => _auth.signOut();

  String _mapAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return 'This email is already registered.';
      case 'invalid-email':
        return 'Invalid email address.';
      case 'weak-password':
        return 'Password is too weak (min 6 characters).';
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password.';
      case 'invalid-phone-number':
        return 'Invalid phone number.';
      case 'too-many-requests':
        return 'Too many attempts. Try again later.';
      default:
        return e.message ?? 'Authentication failed.';
    }
  }
}
