import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/delivery_model.dart';
import 'pricing_service.dart';

class DeliveryService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<String> createDelivery({
    required String requesterId,
    required String pickup,
    required String dropoff,
    required double distanceKm,
    required String vehicleType,
  }) async {
    final price = PricingService.calculatePrice(distanceKm, vehicleType: vehicleType);
    final ref = await _firestore.collection('deliveries').add({
      'requesterId': requesterId,
      'pickupAddress': pickup,
      'dropoffAddress': dropoff,
      'distanceKm': distanceKm,
      'price': price,
      'vehicleType': vehicleType,
      'status': 'pending',
      'createdAt': DateTime.now().toIso8601String(),
    });
    return ref.id;
  }

  Stream<List<DeliveryModel>> getPendingDeliveries() {
    return _firestore
        .collection('deliveries')
        .where('status', isEqualTo: 'pending')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) =>
            snap.docs.map((d) => DeliveryModel.fromMap(d.id, d.data())).toList());
  }

  Future<void> acceptDelivery(String deliveryId, String providerId) async {
    await _firestore.collection('deliveries').doc(deliveryId).update({
      'providerId': providerId,
      'status': 'accepted',
    });
  }

  Future<void> updateStatus(String deliveryId, String status) async {
    await _firestore.collection('deliveries').doc(deliveryId).update({
      'status': status,
    });
  }
}
