class DeliveryModel {
  final String id;
  final String requesterId;
  final String? providerId;
  final String pickupAddress;
  final String dropoffAddress;
  final double distanceKm;
  final double price;
  final String vehicleType;
  final String status; // pending, accepted, in_progress, completed, cancelled
  final DateTime createdAt;

  DeliveryModel({
    required this.id,
    required this.requesterId,
    this.providerId,
    required this.pickupAddress,
    required this.dropoffAddress,
    required this.distanceKm,
    required this.price,
    required this.vehicleType,
    required this.status,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'requesterId': requesterId,
        'providerId': providerId,
        'pickupAddress': pickupAddress,
        'dropoffAddress': dropoffAddress,
        'distanceKm': distanceKm,
        'price': price,
        'vehicleType': vehicleType,
        'status': status,
        'createdAt': createdAt.toIso8601String(),
      };

  factory DeliveryModel.fromMap(String id, Map<String, dynamic> map) =>
      DeliveryModel(
        id: id,
        requesterId: map['requesterId'] ?? '',
        providerId: map['providerId'],
        pickupAddress: map['pickupAddress'] ?? '',
        dropoffAddress: map['dropoffAddress'] ?? '',
        distanceKm: (map['distanceKm'] ?? 0).toDouble(),
        price: (map['price'] ?? 0).toDouble(),
        vehicleType: map['vehicleType'] ?? 'bike',
        status: map['status'] ?? 'pending',
        createdAt: DateTime.parse(
          map['createdAt'] ?? DateTime.now().toIso8601String(),
        ),
      );
}
