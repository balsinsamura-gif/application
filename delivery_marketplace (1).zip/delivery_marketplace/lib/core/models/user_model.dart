class UserModel {
  final String uid;
  final String email;
  final String? phone;
  final String name;
  final String accountType; // 'personal' or 'business'
  final String? category;
  final String? referralCode;
  final bool emailVerified;
  final bool phoneVerified;
  final double rating;
  final int ratingCount;

  UserModel({
    required this.uid,
    required this.email,
    this.phone,
    required this.name,
    required this.accountType,
    this.category,
    this.referralCode,
    this.emailVerified = false,
    this.phoneVerified = false,
    this.rating = 0.0,
    this.ratingCount = 0,
  });

  Map<String, dynamic> toMap() => {
        'uid': uid,
        'email': email,
        'phone': phone,
        'name': name,
        'accountType': accountType,
        'category': category,
        'referralCode': referralCode,
        'emailVerified': emailVerified,
        'phoneVerified': phoneVerified,
        'rating': rating,
        'ratingCount': ratingCount,
        'createdAt': DateTime.now().toIso8601String(),
      };

  factory UserModel.fromMap(Map<String, dynamic> map) => UserModel(
        uid: map['uid'] ?? '',
        email: map['email'] ?? '',
        phone: map['phone'],
        name: map['name'] ?? '',
        accountType: map['accountType'] ?? 'personal',
        category: map['category'],
        referralCode: map['referralCode'],
        emailVerified: map['emailVerified'] ?? false,
        phoneVerified: map['phoneVerified'] ?? false,
        rating: (map['rating'] ?? 0).toDouble(),
        ratingCount: map['ratingCount'] ?? 0,
      );
}
