import 'package:flutter/material.dart';

class SlotsScreen extends StatelessWidget {
  const SlotsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final types = [
      {'type': 'bike', 'label': 'Bike', 'price': 10},
      {'type': 'car', 'label': 'Car', 'price': 25},
      {'type': 'van', 'label': 'Van', 'price': 40},
      {'type': 'truck', 'label': 'Truck', 'price': 70},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Transport Slots')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: types.length,
        itemBuilder: (context, index) {
          final item = types[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: const Icon(Icons.local_shipping, color: Colors.blue),
              title: Text(item['label'] as String),
              subtitle: Text('Available slots: 0  •  \$${item['price']}/slot'),
              trailing: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Buy slot for ${item['label']} — connect payments next',
                      ),
                    ),
                  );
                },
                child: const Text('Buy'),
              ),
            ),
          );
        },
      ),
    );
  }
}
