import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

Future<void> showRatingDialog(
  BuildContext context, {
  required String providerId,
  required String deliveryId,
}) async {
  double rating = 5.0;

  await showDialog(
    context: context,
    builder: (ctx) {
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('Rate this service'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('${rating.toStringAsFixed(1)} stars'),
                Slider(
                  value: rating,
                  min: 1,
                  max: 5,
                  divisions: 4,
                  label: rating.toStringAsFixed(1),
                  onChanged: (v) => setState(() => rating = v),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () async {
                  // Save rating
                  final ratingsRef = FirebaseFirestore.instance
                      .collection('users')
                      .doc(providerId)
                      .collection('ratings');

                  await ratingsRef.add({
                    'deliveryId': deliveryId,
                    'rating': rating,
                    'createdAt': DateTime.now().toIso8601String(),
                  });

                  // Update average (simplified — production should use aggregation)
                  final userRef =
                      FirebaseFirestore.instance.collection('users').doc(providerId);
                  final userDoc = await userRef.get();
                  if (userDoc.exists) {
                    final data = userDoc.data()!;
                    final currentRating = (data['rating'] ?? 0).toDouble();
                    final count = (data['ratingCount'] ?? 0) as int;
                    final newCount = count + 1;
                    final newRating =
                        ((currentRating * count) + rating) / newCount;

                    await userRef.update({
                      'rating': double.parse(newRating.toStringAsFixed(2)),
                      'ratingCount': newCount,
                    });
                  }

                  if (context.mounted) {
                    Navigator.pop(ctx);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Thank you for your rating!')),
                    );
                  }
                },
                child: const Text('Submit'),
              ),
            ],
          );
        },
      );
    },
  );
}
