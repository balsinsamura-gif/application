import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../core/models/user_model.dart';
import '../../core/services/call_service.dart';

class ProfileScreen extends StatelessWidget {
  final String userId;
  const ProfileScreen({super.key, required this.userId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('users').doc(userId).get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: Text('Profile not found'));
          }

          final user = UserModel.fromMap(
            snapshot.data!.data() as Map<String, dynamic>,
          );

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Center(
                child: CircleAvatar(
                  radius: 48,
                  child: Text(
                    user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                    style: const TextStyle(fontSize: 36),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                user.name,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                user.accountType.toUpperCase(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: user.accountType == 'business'
                      ? Colors.orange
                      : Colors.blue,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (user.category != null) ...[
                const SizedBox(height: 4),
                Text(
                  user.category!,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ],
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.star, color: Colors.amber),
                          const SizedBox(width: 8),
                          Text(
                            '${user.rating.toStringAsFixed(1)} (${user.ratingCount} ratings)',
                            style: const TextStyle(fontSize: 16),
                          ),
                        ],
                      ),
                      if (user.referralCode != null) ...[
                        const Divider(height: 24),
                        Text('Referral Code: ${user.referralCode}'),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              if (user.phone != null)
                ElevatedButton.icon(
                  onPressed: () => CallService.callNumber(user.phone!),
                  icon: const Icon(Icons.phone),
                  label: const Text('Call'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () {
                  // Later: implement share with share_plus package
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Share link: app://profile/$userId'),
                    ),
                  );
                },
                icon: const Icon(Icons.share),
                label: const Text('Share Profile'),
              ),
            ],
          );
        },
      ),
    );
  }
}
