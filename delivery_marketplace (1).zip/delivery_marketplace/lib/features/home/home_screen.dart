import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../core/services/auth_service.dart';
import '../delivery/create_delivery_screen.dart';
import '../profiles/profile_screen.dart';
import '../slots/slots_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Delivery Marketplace'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => AuthService().signOut(),
            tooltip: 'Sign out',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(user?.email ?? 'User'),
              subtitle: const Text('Signed in'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                if (user != null) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ProfileScreen(userId: user.uid),
                    ),
                  );
                }
              },
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Actions',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          _ActionTile(
            icon: Icons.add_box_outlined,
            title: 'Create Delivery Request',
            subtitle: 'Request a pickup & delivery',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CreateDeliveryScreen()),
              );
            },
          ),
          _ActionTile(
            icon: Icons.inventory_2_outlined,
            title: 'Transport Slots',
            subtitle: 'Business: buy capacity slots',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SlotsScreen()),
              );
            },
          ),
          _ActionTile(
            icon: Icons.person_outline,
            title: 'My Profile',
            subtitle: 'View and share your profile',
            onTap: () {
              if (user != null) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ProfileScreen(userId: user.uid),
                  ),
                );
              }
            },
          ),
        ],
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: Colors.blue),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
